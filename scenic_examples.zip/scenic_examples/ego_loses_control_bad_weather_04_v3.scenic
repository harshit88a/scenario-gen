# Scenario: Four construction cones are fanned at fixed lateral positions across the full lane and
# shoulder at a fixed distance, creating a denser blockade with an additional outer cone that
# eliminates any shoulder escape route and forces a full-stop or collision decision.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Four static cones at fixed lateral positions that together seal off the full drivable lane width
param DEBRIS_START_DIST = 25
param LATERAL_SPREAD = 1.6

behavior StaticObjectBehavior():
    while True:
        wait

# 3. ROAD GEOMETRY
# Ego cruises at the baseline fixed speed toward the four-cone blockade covering the full lane width
EGO_SPEED = 13

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 1.0),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=EGO_SPEED)

require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Four cones placed at center, inner-left, inner-right, and outer-left to fully seal the lane
debris_spot_center = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DEBRIS_START_DIST

debris_center = new Prop at debris_spot_center offset by (0, 0, 0),
    with blueprint "static.prop.constructioncone",
    with physics True,
    with behavior StaticObjectBehavior()

debris_inner_left = new Prop at debris_spot_center offset by (globalParameters.LATERAL_SPREAD, 0, 0),
    with blueprint "static.prop.constructioncone",
    with physics True,
    with behavior StaticObjectBehavior()

debris_inner_right = new Prop at debris_spot_center offset by (-globalParameters.LATERAL_SPREAD, 0, 0),
    with blueprint "static.prop.constructioncone",
    with physics True,
    with behavior StaticObjectBehavior()

debris_outer_left = new Prop at debris_spot_center offset by (3.2, 0, 0),
    with blueprint "static.prop.constructioncone",
    with physics True,
    with behavior StaticObjectBehavior()

terminate when (distance from ego to EgoSpawnPt) > 70
