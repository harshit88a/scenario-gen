# Scenario: Three construction cones block the full lane width at a fixed distance while the ego
# entry speed is sampled, identifying the speed threshold above which the fixed-width blockade
# causes a collision or forced shoulder departure.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Three cones at fixed positions; ego approach speed is the sole sampled variable across runs
param DEBRIS_START_DIST = 25
param LATERAL_SPREAD = 1.6
param EGO_SPEED = Range(8, 18)

behavior StaticObjectBehavior():
    while True:
        wait

# 3. ROAD GEOMETRY
# Ego spawns on a straight lane and approaches the full-width cone blockade at a sampled speed
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 1.0),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED)

require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Left, center, and right cones placed at fixed distance and fixed lateral spread across the lane
debris_spot_center = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DEBRIS_START_DIST

debris_center = new Prop at debris_spot_center offset by (0, 0, 0),
    with blueprint "static.prop.constructioncone",
    with physics True,
    with behavior StaticObjectBehavior()

debris_left = new Prop at debris_spot_center offset by (globalParameters.LATERAL_SPREAD, 0, 0),
    with blueprint "static.prop.constructioncone",
    with physics True,
    with behavior StaticObjectBehavior()

debris_right = new Prop at debris_spot_center offset by (-globalParameters.LATERAL_SPREAD, 0, 0),
    with blueprint "static.prop.constructioncone",
    with physics True,
    with behavior StaticObjectBehavior()

terminate when (distance from ego to EgoSpawnPt) > 70
