# Scenario: A Tesla Model 3 leading car crawls at a fixed mid slow speed before surging to a fixed mid-high fast speed, combining a recognizable EV silhouette with a balanced crawl-and-surge differential at a mid-range trigger and spawn distance.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial Tesla Model 3 crawls at a fixed mid slow speed of 5 m/s then surges to a fixed mid-high fast speed of 35 m/s when the ego reaches the static mid trigger distance of 14 m; the large 30 m/s differential from a Tesla provides an unexpected speed event.
param ADV_SLOW_SPEED = 5
param ADV_FAST_SPEED = 35
param ADV_DISTANCE = 14

behavior AdvBehavior(target_ego):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SLOW_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    do FollowLaneBehavior(target_speed=globalParameters.ADV_FAST_SPEED)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection so the mid-range Tesla crawl-and-surge event is evaluated in an open straight-road context.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial Tesla Model 3 spawns at a static mid distance of 16 m ahead of the ego; the mid slow speed and mid spawn give the ego a moderate observability window before the 14 m trigger fires and the high-acceleration surge begins.
param GEO_Y_DISTANCE = 16
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with blueprint "vehicle.tesla.model3",
    with behavior AdvBehavior(ego)
