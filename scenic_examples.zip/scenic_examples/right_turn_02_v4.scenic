# Scenario: The ego vehicle is turning right; the adversarial car in the end lane brakes only when the ego is very close; a late brake trigger and a reduced ego safety distance create the minimum-margin stopping scenario.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The adversarial car travels at 10 m/s in the end lane and holds speed until the ego is within only 12 m before braking abruptly; the reduced ego safety detection distance of 10 m means both vehicles are nearly overlapping when the brake chain activates.

param EGO_SPEED = 7
param ADV_SPEED = 10
param BRAKE_INTENSITY = 1.0
param SAFETY_DIST = 10
param ADV_BRAKE_TRIGGER_DIST = 12

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        if withinDistanceToTrafficLight(adversary, 100):
            setClosestTrafficLightStatus(adversary, "green")
        wait

behavior AdversaryBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.ADV_SPEED)
    interrupt when (distance from self to ego) < globalParameters.ADV_BRAKE_TRIGGER_DIST:
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.EGO_SPEED)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)


# 3. ROAD GEOMETRY
### A four-way intersection where the ego turns right and the adversary is 8 m into the end lane; the late 12 m trigger and 10 m ego safety distance represent the worst-case near-miss configuration for the end-lane braking scenario.

ADV_MODEL = "vehicle.tesla.model3"

fourWayIntersections = filter(lambda i: i.is4Way, network.intersections)
intersec = Uniform(*fourWayIntersections)

ego_maneuvers = filter(lambda i: i.type == ManeuverType.RIGHT_TURN, intersec.maneuvers)
ego_maneuver = Uniform(*ego_maneuvers)
ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]

adv_trajectory = [ego_maneuver.endLane]


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### Ego spawns 11 m before the intersection; adversary is anchored 8 m forward from the end lane start; the late 12 m adversary brake trigger and 10 m ego safety threshold create a near-simultaneous braking scenario with the smallest stopping margin.

param EGO_DIST_TO_INTERSECTION = 11
param ADV_DIST_FROM_INTERSECTION = 8

ego_anchor = new OrientedPoint at ego_maneuver.startLane.centerline.end
adv_anchor = new OrientedPoint at ego_maneuver.endLane.centerline.start

ego_spawn_pt = new OrientedPoint following roadDirection from ego_anchor for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_anchor for globalParameters.ADV_DIST_FROM_INTERSECTION

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Car at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with behavior AdversaryBehavior(adv_trajectory)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 100
