# Scenario: An adversarial vehicle in the adjacent right lane travels at a fixed medium speed and gently drifts into the ego's lane from the right side at a mid-range trigger, producing a subtle right-side cut-in that may be harder for the ego to anticipate than the more common left-side variant.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial vehicle follows its adjacent right lane at a fixed medium speed of 18 m/s and applies a static gentle steer intensity of 0.3 into the ego's lane from the right side at the static trigger distance of 12 m; the low steer value produces a gradual drift that is less visually alarming but still encroaches on the ego's lane.
param ADV_SPEED = 18
param ADV_DISTANCE = 12
param STEER_INTENSITY = 0.3

behavior AdvBehavior(target_ego, steer_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetSteerAction(steer_intensity)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection to keep the right-side gentle drift scenario in an open straight-road context without intersection geometry interference.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial car spawns at a static mid distance of 20 m ahead and one lane-width to the right of the ego using a positive lateral offset of +3.5 m; the right-side spawn flips the cut-in direction relative to the baseline, exercising a distinct and less-tested lateral threat axis.
param GEO_Y_DISTANCE = 20
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (3.5, 0, 0.5),
    with behavior AdvBehavior(ego, globalParameters.STEER_INTENSITY)
