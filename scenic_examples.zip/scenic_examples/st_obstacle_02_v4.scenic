# Scenario: Ego vehicle is driving on a straight road; the adversarial pedestrian hidden behind a bus stop is triggered very late and stops almost in contact with the ego. Reduced trigger and stop distances produce the minimum-margin bus-stop ambush scenario.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian does not begin sprinting until the ego is only 12 m away, then dashes at 4.5 m/s and freezes just 1.5 m in front of the ego; the very late trigger and near-contact stop distance represent the worst-case bus-stop ambush with almost no ego stopping margin.

param EGO_SPEED = 10
param PED_SPRINT_SPEED = 4.5
param TRIGGER_DIST = 12
param STOP_DIST = 1.5

behavior PedestrianBusStopAmbushBehavior(sprint_speed, trigger_dist, stop_dist):
    while (distance from self to ego) > trigger_dist:
        take SetWalkingSpeedAction(0)
    while True:
        if (distance from self to ego) <= stop_dist:
            take SetWalkingSpeedAction(0)
            break
        else:
            take SetWalkingDirectionAction(self.heading)
            take SetWalkingSpeedAction(sprint_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 70 m from any intersection; the bus stop reference is placed 24 m ahead; the 12 m trigger means the ego has already covered half the longitudinal gap before the pedestrian moves.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 70
require (distance from spawnPt to initLane.centerline[-1]) > 50


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The pedestrian spawns 24 m ahead and 5.0 m to the right; the late 12 m trigger and 1.5 m stop distance leave the ego only 1.5 m of clearance after the pedestrian freezes, representing the most dangerous bus-stop ambush configuration.

param START_DISTANCE = 24
param LATERAL_OFFSET = 5.0

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

bus_stop_ref = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE
ped_spawn = new OrientedPoint right of bus_stop_ref by globalParameters.LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to bus_stop_ref.heading,
    with regionContainedIn None,
    with behavior PedestrianBusStopAmbushBehavior(
        globalParameters.PED_SPRINT_SPEED,
        globalParameters.TRIGGER_DIST,
        globalParameters.STOP_DIST
    )

require ped not in network.drivableRegion
