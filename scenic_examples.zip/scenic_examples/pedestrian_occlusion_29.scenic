# Scenario: A stationary bus on the shoulder hides a slow pedestrian who is triggered at a far distance while the ego travels slowly, creating a prolonged low-urgency block that tests the ego's patience and sustained yielding behaviour.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.tesla.model3"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Pedestrian moves at 1.5 m/s and triggers at 20 m from the ego; despite the early trigger, the very slow walking speed means the pedestrian is still mid-lane when the slow ego arrives.

param PED_SPEED = 1.5
param TRIGGER_DIST = 20

behavior CrossingWalk(target_speed):
    while True:
        take SetWalkingDirectionAction(self.heading), SetWalkingSpeedAction(target_speed)

behavior PedestrianOcclusionBehavior(target_ego):
    while (distance from target_ego to self) > globalParameters.TRIGGER_DIST:
        wait
    do CrossingWalk(target_speed=globalParameters.PED_SPEED)

behavior ParkedBehavior():
    take SetBrakeAction(1.0)
    take SetHandBrakeAction(True)

# 3. ROAD GEOMETRY
# Straight lane in Town05 clear of intersections; ego cruises slowly at 8 m/s, reducing urgency but extending the waiting period after the pedestrian triggers.

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=8)
require (distance to intersection) > 40

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Bus placed 28 m ahead on the left shoulder; the slow pedestrian is triggered early but must traverse the full lane width at very low speed before the ego can proceed.

param OCCLUDER_DIST = 28
param SIDE_OFFSET = -3.5

bus_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.OCCLUDER_DIST

occluder_bus = new Car at bus_spot offset by (globalParameters.SIDE_OFFSET, 0, 0.5),
    with blueprint "vehicle.mitsubishi.fusorosa",
    with behavior ParkedBehavior()

ped_spawn = new OrientedPoint at (-0.5, 5.0) relative to occluder_bus,
    facing 90 deg relative to occluder_bus

bad_pedestrian = new Pedestrian at ped_spawn,
    with regionContainedIn None,
    with behavior PedestrianOcclusionBehavior(ego)

require (distance from bad_pedestrian to occluder_bus) > 1
