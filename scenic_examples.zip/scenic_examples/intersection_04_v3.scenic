# Scenario: Ego vehicle approaches a 4-way intersection at 9 m/s; the adversarial car from the right travels at 9 m/s and stops mid-left-turn when the ego is 15 m away, creating a tight mid-intersection hazard.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversary from the right travels at 9 m/s, stops mid-turn on a 15 m ego proximity trigger. Ego brakes on 13 m safety threshold.

param EGO_SPEED = 9
param ADV_SPEED = 9
param SAFETY_DIST = 13
param BRAKE_INTENSITY = 1.0
param ADV_BRAKE_INTENSITY = 1.0
param ADV_STOP_TRIGGER_DIST = 15

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        if withinDistanceToTrafficLight(adversary, 100):
            setClosestTrafficLightStatus(adversary, "green")
        wait

behavior AdversaryBehavior(trajectory, connectingLane):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.ADV_SPEED)
    interrupt when (distance from self to ego) < globalParameters.ADV_STOP_TRIGGER_DIST:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.ADV_SPEED) until (self in connectingLane)
        while True:
            take SetBrakeAction(globalParameters.ADV_BRAKE_INTENSITY)

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.EGO_SPEED)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

# 3. ROAD GEOMETRY
# A four-way intersection where the ego proceeds straight and the adversary approaches from the right side road, performs a left turn crossing directly into the ego's path, and stops mid-turn.

ADV_MODEL = "vehicle.tesla.model3"

fourWayIntersections = filter(lambda i: i.is4Way, network.intersections)
intersec = Uniform(*fourWayIntersections)

ego_maneuvers = filter(lambda i: i.type == ManeuverType.STRAIGHT, intersec.maneuvers)
ego_maneuver = Uniform(*ego_maneuvers)
ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]

adv_maneuvers = filter(lambda i: i.type == ManeuverType.LEFT_TURN, ego_maneuver.conflictingManeuvers)
adv_maneuver = Uniform(*adv_maneuvers)
adv_trajectory = [adv_maneuver.startLane, adv_maneuver.connectingLane, adv_maneuver.endLane]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Ego spawns 14 m from intersection; adversary spawns 24 m back on the right-side conflicting lane for tight-trigger mid-turn stop.

param EGO_DIST_TO_INTERSECTION = 14
param ADV_DIST_TO_INTERSECTION = 24

ego_init_pt = new OrientedPoint in ego_maneuver.startLane.centerline
adv_init_pt = new OrientedPoint in adv_maneuver.startLane.centerline

ego_spawn_pt = new OrientedPoint following roadDirection from ego_init_pt for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_init_pt for -globalParameters.ADV_DIST_TO_INTERSECTION

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Car at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with behavior AdversaryBehavior(adv_trajectory, adv_maneuver.connectingLane)

require (adversary.position relative to ego_spawn_pt).x > 0
require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 100
