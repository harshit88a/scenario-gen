# Scenario: The ego vehicle is turning left at an intersection at a fixed slow speed; the adversarial pedestrian crosses at a fixed brisk pace from a close starting position and freezes mid-intersection, producing a scenario where the ego's slow turn compounds the blocking hazard.

# 1. MAP AND MODEL CONFIGURATION

param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial pedestrian walks at a fixed brisk speed of 1.8 m/s and freezes at a static stop threshold of 2.0 m from the intersection connecting lane entry; the ego's fixed slow speed of 6 m/s means it takes longer to reach the blocked arc, extending the conflict duration.

param EGO_SPEED = 6
param ADV_SPEED = 1.8
param SAFETY_DIST = Range(8, 14)
param BRAKE_INTENSITY = 1.0
param ADV_STOP_THRESHOLD = 2.0

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.EGO_SPEED, trajectory=trajectory)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

behavior AdversaryBehavior(stop_point):
    try:
        while True:
            take SetWalkingDirectionAction(self.heading), SetWalkingSpeedAction(globalParameters.ADV_SPEED)
    interrupt when (distance from self to stop_point) < globalParameters.ADV_STOP_THRESHOLD:
        while True:
            take SetWalkingSpeedAction(0)

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        wait

# 3. ROAD GEOMETRY
# All intersections in the network are considered; left-turn and conflicting straight pairs are sampled uniformly to ensure the brisk-pedestrian slow-ego combination is evaluated across diverse Town05 intersection layouts.

ADV_MODEL = "walker.pedestrian.0010"

def get_conflict_pairs(intersections):
    pairs = []
    for intersec in intersections:
        left_turns = filter(lambda m: m.type == ManeuverType.LEFT_TURN, intersec.maneuvers)
        for lt in left_turns:
            conflicts = filter(lambda c: c.type == ManeuverType.STRAIGHT, lt.conflictingManeuvers)
            for c in conflicts:
                pairs.append([lt, c])
    return pairs

all_intersections = network.intersections
valid_pairs = get_conflict_pairs(all_intersections)

require len(valid_pairs) > 0

selected_pair = Uniform(*valid_pairs)
ego_maneuver = selected_pair[0]
adv_maneuver = selected_pair[1]

ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]

intersection_stop_pt = new OrientedPoint at ego_maneuver.connectingLane.centerline.points[0]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The ego spawns at a static 18 m; the pedestrian spawns very close at a static 6 m from the intersection so it reaches the freeze point almost immediately, ensuring the crossing obstacle is established before the slow ego reaches braking distance.

param EGO_DIST_TO_INTERSECTION = 18
param ADV_DIST_TO_INTERSECTION = 6

ego_anchor = new OrientedPoint at ego_maneuver.startLane.centerline.points[-1]
adv_anchor = new OrientedPoint at adv_maneuver.startLane.centerline.points[-1]

ego_spawn_pt = new OrientedPoint following roadDirection from ego_anchor for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_anchor for -globalParameters.ADV_DIST_TO_INTERSECTION

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Pedestrian at adv_spawn_pt,
    with blueprint ADV_MODEL,
    with regionContainedIn None,
    with behavior AdversaryBehavior(intersection_stop_pt)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 80
