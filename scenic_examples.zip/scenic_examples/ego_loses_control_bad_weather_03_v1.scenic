# Scenario: Ego is forced to slalom through a zigzag chain of creased boxes staggered alternately
# left and right at fully deterministic fixed positions, removing all sampling variance to create
# a reproducible slalom course for controlled regression evaluation.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# All distances and lateral offsets are fixed static values; no Range sampling in this variant
param DEBRIS_START_DIST = 18
param DEBRIS_GAP = 9
param LATERAL_OFFSET = 0.9

behavior StaticObjectBehavior():
    while True:
        wait

# 3. ROAD GEOMETRY
# Ego spawns on a straight lane at a fixed moderate speed toward the deterministic zigzag chain
EGO_SPEED = 14

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 1.0),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=EGO_SPEED)

require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Boxes alternate left and right at a fixed gap and fixed lateral width with no positional noise
debris_spot_1 = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DEBRIS_START_DIST

debris1 = new Prop at debris_spot_1 offset by (globalParameters.LATERAL_OFFSET, 0, 0),
    with blueprint "static.prop.creasedbox01",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_2 = new OrientedPoint following roadDirection from debris_spot_1 for globalParameters.DEBRIS_GAP

debris2 = new Prop at debris_spot_2 offset by (-globalParameters.LATERAL_OFFSET, 0, 0),
    with blueprint "static.prop.creasedbox01",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_3 = new OrientedPoint following roadDirection from debris_spot_2 for globalParameters.DEBRIS_GAP

debris3 = new Prop at debris_spot_3 offset by (globalParameters.LATERAL_OFFSET, 0, 0),
    with blueprint "static.prop.creasedbox01",
    with physics True,
    with behavior StaticObjectBehavior()

terminate when (distance from ego to EgoSpawnPt) > 70
