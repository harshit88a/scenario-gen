# Scenario: Ego vehicle makes a left turn at an intersection and must abort the maneuver when a fast-walking pedestrian triggers early at 20 m, appearing to have enough time to clear the path but instead blocking the exit lane as the ego arrives.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial pedestrian walks briskly at 3.0 m/s and triggers at 20 m from the ego; despite the early trigger, the pedestrian does not clear the lane before the ego completes the turn arc.

from scenic.domains.driving.roads import ManeuverType
from scenic.simulators.carla.behaviors import CrossingBehavior

param EGO_SPEED = 10
param PED_SPEED = 3.0
param TRIGGER_DIST = 20

behavior EgoBehavior(trajectory):
    do FollowTrajectoryBehavior(target_speed=globalParameters.EGO_SPEED, trajectory=trajectory)

# 3. ROAD GEOMETRY
# A 3-way or 4-way intersection in Town05 where the ego follows a left-turn trajectory into the exit lane.

intersections = filter(lambda i: i.is4Way or i.is3Way, network.intersections)
intersection = Uniform(*intersections)

left_turns = filter(lambda m: m.type is ManeuverType.LEFT_TURN, intersection.maneuvers)
egoManeuver = Uniform(*left_turns)

egoInitLane = egoManeuver.startLane
egoTrajectory = [egoInitLane, egoManeuver.connectingLane, egoManeuver.endLane]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The pedestrian is at 3.5 m lateral offset from the exit lane start; the early trigger and fast gait create a deceptive timing scenario that causes the ego to misjudge the available gap.

param PED_OFFSET = 3.5

egoSpawnPt = new OrientedPoint in egoInitLane.centerline

ego = new Car at egoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(egoTrajectory)

exit_lane_start = egoManeuver.endLane.centerline[0]
exit_point = new OrientedPoint at exit_lane_start

ped_spawn = new OrientedPoint right of exit_point by globalParameters.PED_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to exit_point.heading,
    with regionContainedIn None,
    with behavior CrossingBehavior(ego, globalParameters.PED_SPEED, globalParameters.TRIGGER_DIST)

require ped not in network.drivableRegion

terminate when (distance to egoSpawnPt) > 70
