# Scenario: Ego vehicle is driving on a straight road; the adversarial pedestrian sprints from behind a bus stop at maximum speed and stops in front of the ego. Mid-range spawn distances with an elevated sprint speed to shorten the crossing time.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian waits behind the bus stop at 26 m ahead until the ego closes to 20 m, then sprints at an elevated 6.0 m/s and freezes 3 m in front of the ego; the higher sprint speed means the pedestrian bursts into the lane much faster, reducing the visual warning time for the ego.

param EGO_SPEED = 10
param PED_SPRINT_SPEED = 6.0
param TRIGGER_DIST = 20
param STOP_DIST = 3

behavior PedestrianBusStopAmbushBehavior(sprint_speed, trigger_dist, stop_dist):
    while (distance from self to ego) > trigger_dist:
        take SetWalkingSpeedAction(0)
    while True:
        if (distance from self to ego) <= stop_dist:
            take SetWalkingSpeedAction(0)
            break
        else:
            take SetWalkingDirectionAction(self.heading)
            take SetWalkingSpeedAction(sprint_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 70 m from any intersection; the bus stop reference is placed 26 m ahead at a mid-range distance, with the pedestrian 5.2 m to the right representing a moderately deep shelter occlusion.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 70
require (distance from spawnPt to initLane.centerline[-1]) > 50


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The pedestrian spawns 26 m ahead and 5.2 m to the right; the elevated 6.0 m/s sprint speed combined with the mid-range lateral offset creates the fastest entry into the ego's lane among the bus-stop variants.

param START_DISTANCE = 26
param LATERAL_OFFSET = 5.2

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

bus_stop_ref = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE
ped_spawn = new OrientedPoint right of bus_stop_ref by globalParameters.LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to bus_stop_ref.heading,
    with regionContainedIn None,
    with behavior PedestrianBusStopAmbushBehavior(
        globalParameters.PED_SPRINT_SPEED,
        globalParameters.TRIGGER_DIST,
        globalParameters.STOP_DIST
    )

require ped not in network.drivableRegion
