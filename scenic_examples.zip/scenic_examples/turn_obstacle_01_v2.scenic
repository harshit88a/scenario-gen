# Scenario: The ego vehicle is turning left at an intersection; the adversarial motorcyclist on the right front approaches at high speed but brakes early before the intersection edge, leaving a wider deceleration window that still causes ego confusion during the left turn.

# 1. MAP AND MODEL CONFIGURATION

param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial motorcyclist travels at a fixed high speed of 12 m/s, then triggers a full brake at a static distance of 7 m from the intersection edge, halting conspicuously before the road boundary and creating an ambiguous deceleration cue for the ego.

param EGO_SPEED = Range(6, 10)
param ADV_SPEED = 12
param SAFETY_DIST = Range(8, 14)
param BRAKE_INTENSITY = 1.0
param ADV_BRAKE_TRIGGER_DIST = 7

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.EGO_SPEED, trajectory=trajectory)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

behavior AdversaryBehavior(trajectory, brake_point):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.ADV_SPEED, trajectory=trajectory)
    interrupt when (distance from self to brake_point) < globalParameters.ADV_BRAKE_TRIGGER_DIST:
        while True:
            take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        wait

# 3. ROAD GEOMETRY
# A 4-way intersection is required; the high-speed motorcyclist needs the longer conflicting straight lane available at 4-way sites so it can decelerate visibly before the brake trigger distance.

ADV_MODEL = "vehicle.harley-davidson.low_rider"

def get_conflict_pairs(intersections):
    pairs = []
    for intersec in intersections:
        left_turns = filter(lambda m: m.type == ManeuverType.LEFT_TURN, intersec.maneuvers)
        for lt in left_turns:
            conflicts = filter(lambda c: c.type == ManeuverType.STRAIGHT, lt.conflictingManeuvers)
            for c in conflicts:
                pairs.append([lt, c])
    return pairs

four_way_intersections = filter(lambda i: i.is4Way, network.intersections)
valid_pairs = get_conflict_pairs(four_way_intersections)

require len(valid_pairs) > 0

selected_pair = Uniform(*valid_pairs)
ego_maneuver = selected_pair[0]
adv_maneuver = selected_pair[1]

ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]
adv_trajectory = [adv_maneuver.startLane, adv_maneuver.connectingLane, adv_maneuver.endLane]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The ego spawns far from the intersection at a static 25 m, giving it time to build speed before the turn; the motorcyclist spawns at a static 18 m back so that at high speed it arrives at the brake trigger before the ego completes the turning arc.

param EGO_DIST_TO_INTERSECTION = 25
param ADV_DIST_TO_INTERSECTION = 18

ego_anchor = new OrientedPoint at ego_maneuver.startLane.centerline.points[-1]
adv_anchor = new OrientedPoint at adv_maneuver.startLane.centerline.points[-1]

ego_spawn_pt = new OrientedPoint following roadDirection from ego_anchor for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_anchor for -globalParameters.ADV_DIST_TO_INTERSECTION

adv_brake_point = new OrientedPoint at adv_maneuver.startLane.centerline.points[-1]

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Motorcycle at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with behavior AdversaryBehavior(adv_trajectory, adv_brake_point)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 80
