# Scenario: Ego vehicle drives straight and must react when a very slow pedestrian crosses from the left shoulder at an early trigger distance, creating a long-duration lane-blocking event that challenges the ego's gap-assessment logic.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial pedestrian shuffles at only 1.0 m/s and triggers at 20 m from the ego; the very slow speed keeps the pedestrian inside the lane for an extended time, requiring sustained braking.

from scenic.simulators.carla.behaviors import CrossingBehavior

param EGO_SPEED = 10
param PED_SPEED = 1.0
param TRIGGER_DIST = 20

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)

# 3. ROAD GEOMETRY
# A straight road with no intersection nearby, placing the entire burden of detection and response on the ego's perception of the slow-moving pedestrian.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The pedestrian is placed 22 m ahead on the front-left shoulder at a 3.5 m lateral offset, stepping rightward across the road and blocking the lane for the full duration of the slow crossing.

param START_DISTANCE = 22
param LATERAL_OFFSET = 3.5

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

adv_spot_road = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE
ped_spawn = new OrientedPoint left of adv_spot_road by globalParameters.LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing -90 deg relative to adv_spot_road.heading,
    with regionContainedIn None,
    with behavior CrossingBehavior(ego, globalParameters.PED_SPEED, globalParameters.TRIGGER_DIST)

require ped not in network.drivableRegion
