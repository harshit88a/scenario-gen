# Scenario: Three creasedbox02 props are scattered at fixed moderate distances with a narrower
# lateral band, reducing the debris count while tightening the lateral hazard window to test
# whether fewer but more centrally placed obstacles produce higher collision rates.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Three creasedbox02 props at fixed moderate gaps with narrow fixed lateral offsets for central hazard
param DEBRIS_START_DIST = 22
param DEBRIS_GAP = 14

behavior StaticObjectBehavior():
    while True:
        wait

# 3. ROAD GEOMETRY
# Ego drives at the baseline reference speed across a moderately long straight lane section
EGO_SPEED = 11

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 1.0),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=EGO_SPEED)

require (distance to intersection) > 80

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Three boxes at fixed moderate gaps with narrow fixed lateral offsets to maximise center-lane impact
debris_spot_1 = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DEBRIS_START_DIST

debris1 = new Prop at debris_spot_1 offset by (0.4, 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_2 = new OrientedPoint following roadDirection from debris_spot_1 for globalParameters.DEBRIS_GAP

debris2 = new Prop at debris_spot_2 offset by (-0.4, 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_3 = new OrientedPoint following roadDirection from debris_spot_2 for globalParameters.DEBRIS_GAP

debris3 = new Prop at debris_spot_3 offset by (0.0, 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

terminate when (distance from ego to EgoSpawnPt) > 100
