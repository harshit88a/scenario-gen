# Scenario: Unprotected left turn at intersection where the ego yields to a fast-approaching oncoming vehicle that undergoes a throttle fault at very close range, leaving the ego almost no time to abort the turn.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"



# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversary travels fast at 16 m/s and the throttle fault trips at only 25 m from the ego, surging to 35 m/s and creating an extreme closing rate with virtually no reaction window for the ego.

param EGO_SPEED = 8
param ADV_SPEED = 16
param ADV_SURGE_SPEED = 35
param SAFETY_DIST = 18
param BRAKE_INTENSITY = 1.0
param THROTTLE_FAULT_DIST = 25

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        if withinDistanceToTrafficLight(adversary, 100):
            setClosestTrafficLightStatus(adversary, "green")
        wait

behavior AdversaryBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.ADV_SPEED)
    interrupt when (distance from self to ego) < globalParameters.THROTTLE_FAULT_DIST:
        take SetThrottleAction(1.0)
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.ADV_SURGE_SPEED)

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.EGO_SPEED)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

# 3. ROAD GEOMETRY
# Four-way intersection in Town05 where the ego executes a left turn against the oncoming straight-travelling adversary.

ADV_MODEL = "vehicle.tesla.model3"

fourWayIntersections = filter(lambda i: i.is4Way, network.intersections)
intersec = Uniform(*fourWayIntersections)

ego_maneuvers = filter(lambda i: i.type == ManeuverType.LEFT_TURN, intersec.maneuvers)
ego_maneuver = Uniform(*ego_maneuvers)
ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]

adv_maneuvers = filter(lambda i: i.type == ManeuverType.STRAIGHT, ego_maneuver.conflictingManeuvers)
adv_maneuver = Uniform(*adv_maneuvers)
adv_trajectory = [adv_maneuver.startLane, adv_maneuver.connectingLane, adv_maneuver.endLane]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Ego placed 18 m back from the intersection; adversary placed 45 m away, ensuring the fault fires deep into the ego's turning maneuver.

param EGO_DIST_TO_INTERSECTION = 18
param ADV_DIST_TO_INTERSECTION = 45

ego_init_pt = new OrientedPoint in ego_maneuver.startLane.centerline
adv_init_pt = new OrientedPoint in adv_maneuver.startLane.centerline

ego_spawn_pt = new OrientedPoint following roadDirection from ego_init_pt for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_init_pt for -globalParameters.ADV_DIST_TO_INTERSECTION

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Car at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with behavior AdversaryBehavior(adv_trajectory)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 100
