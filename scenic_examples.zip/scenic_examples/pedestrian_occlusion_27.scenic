# Scenario: A stationary bus occludes a pedestrian who drifts into the ego's path at the minimum sampled speed and the nearest sampled bus position, testing the ego at the least forgiving end of the large-occluder scenario range.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.tesla.model3"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Pedestrian moves at a fixed slow 1.2 m/s and triggers at a fixed 16 m from the ego; the nearest bus position means the pedestrian is hidden until the very last moment before trigger.

param PED_SPEED = 1.2
param TRIGGER_DIST = 16

behavior CrossingWalk(target_speed):
    while True:
        take SetWalkingDirectionAction(self.heading), SetWalkingSpeedAction(target_speed)

behavior PedestrianOcclusionBehavior(target_ego):
    while (distance from target_ego to self) > globalParameters.TRIGGER_DIST:
        wait
    do CrossingWalk(target_speed=globalParameters.PED_SPEED)

behavior ParkedBehavior():
    take SetBrakeAction(1.0)
    take SetHandBrakeAction(True)

# 3. ROAD GEOMETRY
# Straight lane in Town05 clear of intersections; ego cruises at 10 m/s toward the nearest bus placement.

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=10)
require (distance to intersection) > 40

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Bus placed 22 m ahead on the left shoulder; slow pedestrian hides at the standard relative offset behind the large bus body and steps into the lane at trigger.

param OCCLUDER_DIST = 22
param SIDE_OFFSET = -3.5

bus_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.OCCLUDER_DIST

occluder_bus = new Car at bus_spot offset by (globalParameters.SIDE_OFFSET, 0, 0.5),
    with blueprint "vehicle.mitsubishi.fusorosa",
    with behavior ParkedBehavior()

ped_spawn = new OrientedPoint at (-0.5, 5.0) relative to occluder_bus,
    facing 90 deg relative to occluder_bus

bad_pedestrian = new Pedestrian at ped_spawn,
    with regionContainedIn None,
    with behavior PedestrianOcclusionBehavior(ego)

require (distance from bad_pedestrian to occluder_bus) > 1
