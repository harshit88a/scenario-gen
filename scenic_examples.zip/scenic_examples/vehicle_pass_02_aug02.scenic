# Scenario: Ego bypasses a parked car using the opposite lane, yields to fast oncoming traffic (12 m/s), then encounters a high-speed oncoming motorcyclist (14 m/s) that swerves into its lane, requiring emergency braking. All range parameters sampled at upper bounds.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Ego detects parked car, yields at the edge of its lane until the fast oncoming car (12 m/s) clears, changes into the opposing lane to bypass, returns to original lane, then brakes hard when the high-speed motorcyclist (14 m/s) swerves into its path. The oncoming car travels straight through. The motorcyclist follows its lane until close to ego, then swerves into the ego's original lane.

param EGO_SPEED          = 10
param ONCOMING_SPEED     = 12
param MOTO_SPEED         = 14
param BYPASS_TRIGGER_DIST = 20
param BYPASS_CLEAR_DIST   = 15
param YIELD_DIST          = 30
param BRAKE_TRIGGER_DIST  = 18

behavior EgoBehavior(opposingSection, originalSection):
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance from self to parkedCar) < globalParameters.BYPASS_TRIGGER_DIST

    while (distance from self to oncomingCar) < globalParameters.YIELD_DIST:
        take SetBrakeAction(0.8)

    do LaneChangeBehavior(laneSectionToSwitch=opposingSection,
                          target_speed=globalParameters.EGO_SPEED)

    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance from self to parkedCar) > globalParameters.BYPASS_CLEAR_DIST

    do LaneChangeBehavior(laneSectionToSwitch=originalSection,
                          target_speed=globalParameters.EGO_SPEED)

    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance from self to motorcyclist) < globalParameters.BRAKE_TRIGGER_DIST

    while True:
        take SetBrakeAction(1.0)

behavior OncomingCarBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ONCOMING_SPEED)

behavior MotorcyclistBehavior(egoLaneSection):
    do FollowLaneBehavior(target_speed=globalParameters.MOTO_SPEED) until \
        (distance from self to ego) < 25
    do LaneChangeBehavior(laneSectionToSwitch=egoLaneSection,
                          target_speed=globalParameters.MOTO_SPEED)
    do FollowLaneBehavior(target_speed=globalParameters.MOTO_SPEED)


# 3. ROAD GEOMETRY
# Ego is placed on a straight lane away from intersections. A left offset point resolves the opposing lane section for bypass. A right offset from that recovers the original lane section for return. Both are passed into EgoBehavior at construction time. The same original section is passed to the motorcyclist as its swerve target.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

leftCheckPt  = new OrientedPoint left of spawnPt by 3.5
opposingSection = network.laneSectionAt(leftCheckPt)

rightCheckPt = new OrientedPoint right of leftCheckPt by 3.5
originalSection = network.laneSectionAt(rightCheckPt)

require opposingSection is not None
require getattr(opposingSection, 'lane', None) != initLane
require originalSection is not None

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(opposingSection, originalSection)

require (distance to intersection) > 80


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Parked car blocks ego's lane. Oncoming car is placed at upper-bound distance, giving the yield phase a wider initial window before the fast vehicle closes in. Motorcyclist is placed at upper-bound distance in the opposing lane and swerves into ego's original lane after the bypass. All distances sampled at upper bounds.

param DIST_EGO_TO_PARKED     = 30
param DIST_EGO_TO_ONCOMING   = 42
param DIST_EGO_TO_MOTO       = 70

parked_spot  = new OrientedPoint following roadDirection from spawnPt for globalParameters.DIST_EGO_TO_PARKED
oncoming_spot = new OrientedPoint following roadDirection from spawnPt for globalParameters.DIST_EGO_TO_ONCOMING
moto_spot    = new OrientedPoint following roadDirection from spawnPt for globalParameters.DIST_EGO_TO_MOTO

parkedCar = new Car at parked_spot offset by (0, 0, 0.5),
    with blueprint "vehicle.tesla.model3"

oncomingCar = new Car at oncoming_spot offset by (0, 0, 0.5),
    facing 180 deg relative to roadDirection,
    with behavior OncomingCarBehavior()

motorcyclist = new Car at moto_spot offset by (0, 0, 0.5),
    with blueprint "vehicle.harley-davidson.low_rider",
    facing 180 deg relative to roadDirection,
    with behavior MotorcyclistBehavior(originalSection)

require (distance from parkedCar to intersection) > 50

terminate when ego.speed < 0.5 and (distance from ego to motorcyclist) < 6
