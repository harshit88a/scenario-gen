# Scenario: A lead vehicle brakes hard at a laterally offset trash bin that partially blocks the lane; all sampled distances, lead speed, and lateral offset are converted to fixed static values to create a fully reproducible partial-obstruction chain-reaction benchmark.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Lead car drives at a fixed speed and brakes at a fixed trigger distance from the offset trash bin
param LEAD_SPEED = 12
param OBSTACLE_BRAKE_DIST = 13
param BRAKE_FORCE = 1.0

behavior LeadCarBehavior(target_obstacle, brake_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.LEAD_SPEED) until \
        (distance from target_obstacle to self) < globalParameters.OBSTACLE_BRAKE_DIST
    while True:
        take SetBrakeAction(brake_intensity)

# 3. ROAD GEOMETRY
# Ego drives straight at a fixed reference speed toward the partially blocked lane ahead
EGO_SPEED = 12

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=EGO_SPEED)

require (distance to intersection) > 80

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Lead car and offset trash bin placed at fixed static distances with a fixed lateral offset
param DIST_EGO_TO_LEAD = 12
param DIST_LEAD_TO_OBSTACLE = 35
param OBSTACLE_LATERAL_OFFSET = 0.8

lead_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DIST_EGO_TO_LEAD

obs_spot = new OrientedPoint following roadDirection from lead_spot for globalParameters.DIST_LEAD_TO_OBSTACLE

obstacle = new Prop at obs_spot offset by (globalParameters.OBSTACLE_LATERAL_OFFSET, 0, 0.5),
    with blueprint "static.prop.trashcan01"

leadCar = new Car at lead_spot offset by (0, 0, 0.5),
    with behavior LeadCarBehavior(obstacle, globalParameters.BRAKE_FORCE)

terminate when ego.speed < 0.1 and (distance to leadCar) < 5
