# Scenario: Ego vehicle is driving on a straight road; a pedestrian hidden behind a vending machine on the right dashes out and stops in front of the ego. Static parameters sampled at the lower bound of the original Range distributions.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian stands motionless behind the vending machine 20 m ahead until the ego closes to 20 m, then dashes leftward at 4.0 m/s and freezes 3.0 m in front of the ego; lower-bound spawn and offset values place the machine and pedestrian closest to the lane, creating the tightest occlusion geometry.

param EGO_SPEED = 10
param PED_DASH_SPEED = 4.0
param TRIGGER_DIST = 20
param STOP_DIST = 3.0

behavior PedestrianVendingMachineAmbushBehavior(dash_speed, trigger_dist, stop_dist):
    while (distance from self to ego) > trigger_dist:
        take SetWalkingSpeedAction(0)
    while True:
        if (distance from self to ego) <= stop_dist:
            take SetWalkingSpeedAction(0)
            break
        else:
            take SetWalkingDirectionAction(self.heading)
            take SetWalkingSpeedAction(dash_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 70 m from any intersection; the vending machine reference is placed 20 m ahead with the machine 3.5 m to the right and the pedestrian 4.2 m to the right with a 0.6 m rearward hide offset.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 70
require (distance from spawnPt to initLane.centerline[-1]) > 50


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The vending machine sits 20 m ahead and 3.5 m right; the pedestrian hides 4.2 m right and 0.6 m rearward; lower-bound offsets create the minimum lateral separation between pedestrian and lane, so the dash covers the shortest possible distance before the freeze.

param START_DISTANCE = 20
param VM_LATERAL_OFFSET = 3.5
param PED_HIDE_OFFSET = 0.6
param PED_LATERAL_OFFSET = 4.2

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

vm_ref = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE

vending_machine = new Prop right of vm_ref by globalParameters.VM_LATERAL_OFFSET,
    with blueprint "static.prop.vendingmachine",
    facing vm_ref.heading,
    with regionContainedIn None

ped_spawn = new OrientedPoint right of vm_ref by globalParameters.PED_LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (-globalParameters.PED_HIDE_OFFSET, 0, 1),
    facing 90 deg relative to vm_ref.heading,
    with regionContainedIn None,
    with behavior PedestrianVendingMachineAmbushBehavior(
        globalParameters.PED_DASH_SPEED,
        globalParameters.TRIGGER_DIST,
        globalParameters.STOP_DIST
    )

require ped not in network.drivableRegion
require vending_machine not in network.drivableRegion
