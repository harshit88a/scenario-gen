# Scenario: Ego approaches at a fixed high speed and encounters an adversarial vehicle applying partial brakes ahead at a mid-range distance, simulating a slowly creeping stall that is less visually obvious than a full stop but still demands prompt emergency braking.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial vehicle applies a partial brake force of 0.8 for the entire scenario duration, producing a very slow creep rather than a full stop; the reduced deceleration signal is harder for the ego to interpret as a stopped obstacle, increasing the hazard level.
param BRAKE_FORCE = 0.8

behavior AdvBehavior():
    while True:
        take SetBrakeAction(globalParameters.BRAKE_FORCE)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection and runs at a fixed high approach speed of 18 m/s, reducing the available time to identify and react to the slowly creeping obstacle ahead.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=18)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial vehicle spawns at a static mid-range distance of 20 m ahead; the high ego approach speed and partial-brake creep together create a scenario where the obstacle's slow movement masks its danger until braking margin is nearly exhausted.
param GEO_Y_DISTANCE = 20
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior AdvBehavior()
