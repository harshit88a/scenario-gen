# Scenario: Ego vehicle is driving on a straight road; the adversarial pedestrian emerges from a deep driveway on the left, stops mid-road, then walks diagonally across the lane. Static parameters sampled at the upper bound of the original Range distributions.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian idles at the driveway mouth 26 m ahead until the ego closes to 22 m; it then emerges rightward at 3.0 m/s, stops for 30 ticks mid-road, then walks diagonally at 1.5 m/s at 45 degrees; upper-bound spawn distances give the ego more time but the deeper driveway setback of 2.0 m creates a longer emergence path into the road.

param EGO_SPEED = 10
param PED_INITIAL_SPEED = 3.0
param PED_DIAGONAL_SPEED = 1.5
param TRIGGER_DIST = 22
param STOP_DURATION = 30
param DIAGONAL_ANGLE = 45

behavior PedestrianDrivewayDiagonalBehavior(initial_speed, diagonal_speed, trigger_dist, stop_duration, diagonal_angle):
    while (distance from self to ego) > trigger_dist:
        take SetWalkingSpeedAction(0)
    while (distance from self to ego) > (trigger_dist - 6):
        take SetWalkingDirectionAction(self.heading)
        take SetWalkingSpeedAction(initial_speed)
    for _ in range(stop_duration):
        take SetWalkingSpeedAction(0)
    diag_heading = self.heading + diagonal_angle deg
    while True:
        take SetWalkingDirectionAction(diag_heading)
        take SetWalkingSpeedAction(diagonal_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 70 m from any intersection; the driveway reference is placed 26 m ahead at the upper-bound distance, giving the pedestrian maximum emergence distance before the trigger window opens.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 70
require (distance from spawnPt to initLane.centerline[-1]) > 50


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The pedestrian spawns 26 m ahead and 5.5 m to the left with a 2.0 m rearward driveway setback; the maximum lateral offset and deepest setback simulate a pedestrian stepping out from well inside a wide driveway, requiring the most crossing distance.

param START_DISTANCE = 26
param LATERAL_OFFSET = 5.5
param DRIVEWAY_SETBACK = 2.0

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

driveway_ref = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE

ped_spawn = new OrientedPoint left of driveway_ref by globalParameters.LATERAL_OFFSET,
    facing driveway_ref.heading

ped = new Pedestrian at ped_spawn offset by (-globalParameters.DRIVEWAY_SETBACK, 0, 1),
    facing 270 deg relative to driveway_ref.heading,
    with regionContainedIn None,
    with behavior PedestrianDrivewayDiagonalBehavior(
        globalParameters.PED_INITIAL_SPEED,
        globalParameters.PED_DIAGONAL_SPEED,
        globalParameters.TRIGGER_DIST,
        globalParameters.STOP_DURATION,
        globalParameters.DIAGONAL_ANGLE
    )

require ped not in network.drivableRegion
