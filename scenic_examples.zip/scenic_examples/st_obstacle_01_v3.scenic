# Scenario: Ego vehicle is driving on a straight road; the adversarial pedestrian sprints from the right front at elevated speed and stops in front of the ego. Mid-range spawn distances with a faster pedestrian crossing speed to reduce the ego's available reaction time.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian waits until the ego closes to 18 m then sprints leftward at an elevated 3.5 m/s and freezes 4 m in front of the ego; the higher speed means the pedestrian reaches the lane centreline much faster, compressing the ego's reaction window significantly compared to the base scenario.

param EGO_SPEED = 10
param PED_SPEED = 3.5
param TRIGGER_DIST = 18
param STOP_DIST = 4

behavior PedestrianCrossAndStopBehavior(ped_speed, trigger_dist, stop_dist):
    while (distance from self to ego) > trigger_dist:
        wait
    while True:
        if (distance from self to ego) <= stop_dist:
            take SetWalkingSpeedAction(0)
            break
        else:
            take SetWalkingDirectionAction(self.heading)
            take SetWalkingSpeedAction(ped_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 60 m from any intersection; the ego spawns at the lane centreline and the pedestrian reference point is placed 24 m ahead at a mid-range position.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 60


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The pedestrian spawns 24 m ahead and 4.0 m to the right; at 3.5 m/s crossing speed and only 24 m longitudinal separation, the pedestrian reaches the ego's lane almost twice as fast as the base scenario, making this the most time-critical cross-and-stop variant.

param START_DISTANCE = 24
param LATERAL_OFFSET = 4.0

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

adv_spot_road = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE
ped_spawn = new OrientedPoint right of adv_spot_road by globalParameters.LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to adv_spot_road.heading,
    with regionContainedIn None,
    with behavior PedestrianCrossAndStopBehavior(globalParameters.PED_SPEED, globalParameters.TRIGGER_DIST, globalParameters.STOP_DIST)

require ped not in network.drivableRegion
