# Scenario: Ego vehicle is driving on a straight road; the adversarial pedestrian hidden behind a bus stop sprints out and stops in front of the ego. Static parameters sampled at the lower bound of the original Range distributions.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian stands motionless behind the bus stop at 22 m ahead until the ego closes to 20 m, then sprints at 4.5 m/s across the road and freezes 3 m in front of the ego; the minimum spawn distances create the tightest timing between ambush trigger and ego arrival.

param EGO_SPEED = 10
param PED_SPRINT_SPEED = 4.5
param TRIGGER_DIST = 20
param STOP_DIST = 3

behavior PedestrianBusStopAmbushBehavior(sprint_speed, trigger_dist, stop_dist):
    while (distance from self to ego) > trigger_dist:
        take SetWalkingSpeedAction(0)
    while True:
        if (distance from self to ego) <= stop_dist:
            take SetWalkingSpeedAction(0)
            break
        else:
            take SetWalkingDirectionAction(self.heading)
            take SetWalkingSpeedAction(sprint_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 70 m from any intersection; the ego spawns at the lane centreline and the bus stop reference is placed 22 m ahead with the pedestrian 4.5 m to the right simulating a shelter occlusion.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 70
require (distance from spawnPt to initLane.centerline[-1]) > 50


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The pedestrian spawns 22 m ahead and 4.5 m to the right behind the simulated bus shelter; at the lower-bound lateral offset the pedestrian needs to cross less road to reach the ego's path, shortening the time-in-lane before the freeze.

param START_DISTANCE = 22
param LATERAL_OFFSET = 4.5

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

bus_stop_ref = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE
ped_spawn = new OrientedPoint right of bus_stop_ref by globalParameters.LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to bus_stop_ref.heading,
    with regionContainedIn None,
    with behavior PedestrianBusStopAmbushBehavior(
        globalParameters.PED_SPRINT_SPEED,
        globalParameters.TRIGGER_DIST,
        globalParameters.STOP_DIST
    )

require ped not in network.drivableRegion
