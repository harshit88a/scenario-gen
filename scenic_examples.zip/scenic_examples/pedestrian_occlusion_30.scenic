# Scenario: A stationary bus occludes an extremely slow pedestrian who triggers at a close distance while the ego travels at high speed, producing the most severe time-to-collision in the bus-occlusion scenario family.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.tesla.model3"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Pedestrian shuffles at only 0.8 m/s and triggers at 14 m from the ego; the extremely slow gait combined with the high ego speed leaves the pedestrian completely blocking the lane as the vehicle arrives.

param PED_SPEED = 0.8
param TRIGGER_DIST = 14

behavior CrossingWalk(target_speed):
    while True:
        take SetWalkingDirectionAction(self.heading), SetWalkingSpeedAction(target_speed)

behavior PedestrianOcclusionBehavior(target_ego):
    while (distance from target_ego to self) > globalParameters.TRIGGER_DIST:
        wait
    do CrossingWalk(target_speed=globalParameters.PED_SPEED)

behavior ParkedBehavior():
    take SetBrakeAction(1.0)
    take SetHandBrakeAction(True)

# 3. ROAD GEOMETRY
# Straight lane in Town05 clear of intersections; ego cruises at 14 m/s, the highest ego speed in this scenario family, maximising the danger of the close trigger and barely-moving pedestrian.

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=14)
require (distance to intersection) > 40

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Bus placed 25 m ahead on the left shoulder; the nearly stationary pedestrian hides behind the large bus body and is triggered at the closest distance in this set, giving the fast ego the least possible reaction time.

param OCCLUDER_DIST = 25
param SIDE_OFFSET = -3.5

bus_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.OCCLUDER_DIST

occluder_bus = new Car at bus_spot offset by (globalParameters.SIDE_OFFSET, 0, 0.5),
    with blueprint "vehicle.mitsubishi.fusorosa",
    with behavior ParkedBehavior()

ped_spawn = new OrientedPoint at (-0.5, 5.0) relative to occluder_bus,
    facing 90 deg relative to occluder_bus

bad_pedestrian = new Pedestrian at ped_spawn,
    with regionContainedIn None,
    with behavior PedestrianOcclusionBehavior(ego)

require (distance from bad_pedestrian to occluder_bus) > 1
