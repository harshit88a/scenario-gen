# Scenario: A fast tailgater spawns far behind the ego at maximum adversarial speed, charges at full pace across a large gap and brakes with firm force at a generous trigger distance, producing a high-speed approach with a longer observable closure phase before the braking event.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial tailgater charges at a fixed maximum speed of 35 m/s and applies a firm brake force of 0.8 at a static distance of 10 m from the ego; the high speed and moderate brake force create a dramatic closure event with a firm but non-maximum deceleration.
param ADV_SPEED = 35
param ADV_DISTANCE = 10
param BRAKE_FORCE = 0.8

behavior AdvBehavior(target_ego, brake_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetBrakeAction(brake_intensity)

# 3. ROAD GEOMETRY
# The ego spawns ahead of the adversarial base point on a straight lane at the maximum static separation gap of 45 m, giving the maximum-speed tailgater a long runway to build visible closure speed before the brake trigger.
param GEO_Y_DISTANCE = 45
lane = Uniform(*network.lanes)
advBasePt = new OrientedPoint on lane.centerline
EgoSpawnPt = new OrientedPoint following roadDirection from advBasePt for globalParameters.GEO_Y_DISTANCE
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial tailgater spawns at the lane base point 45 m behind the ego; the maximum approach speed closes the large gap rapidly, making the transition from distant follower to near-collision threat very abrupt.
advAgent = new Car at advBasePt offset by (0, 0, 0.5),
    with behavior AdvBehavior(ego, globalParameters.BRAKE_FORCE)
