# Scenario: Ego vehicle is driving on a straight road; a pedestrian hidden behind a parked car on the right dashes out and stops in front of the ego. Static parameters sampled at the lower bound of the original Range distributions.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian hides behind the parked car 20 m ahead until the ego closes to 20 m, then dashes at 3.5 m/s leftward into the lane and freezes 3.5 m in front of the ego; lower-bound spawn distances and offsets create the tightest occlusion configuration.

param EGO_SPEED = 10
param PED_EMERGE_SPEED = 3.5
param TRIGGER_DIST = 20
param STOP_DIST = 3.5

behavior PedestrianParkedCarAmbushBehavior(emerge_speed, trigger_dist, stop_dist):
    while (distance from self to ego) > trigger_dist:
        take SetWalkingSpeedAction(0)
    while True:
        if (distance from self to ego) <= stop_dist:
            take SetWalkingSpeedAction(0)
            break
        else:
            take SetWalkingDirectionAction(self.heading)
            take SetWalkingSpeedAction(emerge_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 70 m from any intersection; the parked car reference is placed 20 m ahead with the car 3.0 m to the right on the shoulder and the pedestrian 4.0 m to the right behind it.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 70
require (distance from spawnPt to initLane.centerline[-1]) > 50


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The parked car sits 20 m ahead and 3.0 m right of the centreline; the pedestrian hides 4.0 m right and 1.5 m rearward; lower-bound offsets place both objects closest to the lane, maximising the occlusion geometry and minimising the pedestrian's crossing distance.

param START_DISTANCE = 20
param CAR_LATERAL_OFFSET = 3.0
param PED_HIDE_OFFSET = 1.5
param PED_LATERAL_OFFSET = 4.0

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

parked_car_ref = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE

parked_car = new Car right of parked_car_ref by globalParameters.CAR_LATERAL_OFFSET,
    with blueprint Uniform(
        "vehicle.tesla.model3",
        "vehicle.toyota.prius",
        "vehicle.audi.a2"
    ),
    with behavior None

ped_spawn = new OrientedPoint right of parked_car_ref by globalParameters.PED_LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (-globalParameters.PED_HIDE_OFFSET, 0, 1),
    facing 90 deg relative to parked_car_ref.heading,
    with regionContainedIn None,
    with behavior PedestrianParkedCarAmbushBehavior(
        globalParameters.PED_EMERGE_SPEED,
        globalParameters.TRIGGER_DIST,
        globalParameters.STOP_DIST
    )

require ped not in network.drivableRegion
require parked_car not in network.drivableRegion
