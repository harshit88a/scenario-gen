# Scenario: Ego drives straight; a Tesla Model 3 leading car is already effectively stopped (speed 0) and holds maximum brakes the instant the ego reaches a static trigger distance, simulating a pre-stalled vehicle that the ego discovers only when dangerously close.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial Tesla Model 3 idles at a fixed speed of 0 m/s and applies maximum brake force of 1.0 the instant the ego enters the static trigger zone of 12 m, effectively behaving as a pre-stalled obstacle that holds its position until impact or ego stop.
param ADV_SPEED = 0
param ADV_DISTANCE = 12
param BRAKE_FORCE = 1.0

behavior AdvBehavior(target_ego, brake_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetBrakeAction(brake_intensity)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection so the pre-stalled obstacle scenario is not conflated with intersection logic.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial Tesla Model 3 spawns at a static 28 m ahead of the ego; the far spawn combined with zero ADV speed means the ego approaches at full speed before any observable cue signals the obstacle.
param GEO_Y_DISTANCE = 28
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with blueprint "vehicle.tesla.model3",
    with behavior AdvBehavior(ego, globalParameters.BRAKE_FORCE)
