# Scenario: An Audi E-Tron tailgater spawns behind the ego at a fixed mid-high speed, charges to a mid-range brake trigger and applies near-maximum brakes, combining a different EV silhouette with a balanced high-speed rear-approach threat.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial Audi E-Tron charges at a fixed mid-high speed of 28 m/s and applies a near-maximum brake force of 0.9 at a static mid-range trigger distance of 7 m from the ego; the near-max deceleration and moderate trigger gap produce a realistic high-speed emergency braking event.
param ADV_SPEED = 28
param ADV_DISTANCE = 7
param BRAKE_FORCE = 0.9

behavior AdvBehavior(target_ego, brake_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetBrakeAction(brake_intensity)

# 3. ROAD GEOMETRY
# The ego spawns ahead of the adversarial base point on a straight lane at a static gap of 35 m, giving the mid-high-speed tailgater enough runway to build momentum before reaching the 7 m trigger.
param GEO_Y_DISTANCE = 35
lane = Uniform(*network.lanes)
advBasePt = new OrientedPoint on lane.centerline
EgoSpawnPt = new OrientedPoint following roadDirection from advBasePt for globalParameters.GEO_Y_DISTANCE
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial Audi E-Tron spawns at the lane base point 35 m behind the ego, far enough for the mid-high approach speed to generate a visibly dangerous closure rate before the near-maximum brake fires at 7 m.
advAgent = new Car at advBasePt offset by (0, 0, 0.5),
    with blueprint "vehicle.audi.etron",
    with behavior AdvBehavior(ego, globalParameters.BRAKE_FORCE)
