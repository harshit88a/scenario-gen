# Scenario: Ego vehicle drives straight; a pedestrian dashes from behind a parked vehicle at the closest possible distance and freezes in the ego's lane, forcing an emergency stop at low ego speed.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The pedestrian dashes at 1.5 m/s for 1.5 seconds before freezing in the lane; even at low ego speed the close parked distance leaves minimal braking room.

param EGO_SPEED = 8
param PED_SPEED = 1.5
param PED_WALK_DURATION = 1.5

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)

behavior ParkedBehavior():
    take SetHandBrakeAction(True)

behavior CrossAndFreeze(ego, speed, duration):
    do CrossingBehavior(lambda: ego, speed, 300) for duration seconds
    terminate

# 3. ROAD GEOMETRY
# A straight road with a parking shoulder on the right side, at least 50 m from the nearest intersection.

from scenic.simulators.carla.behaviors import FollowLaneBehavior, CrossingBehavior
from scenic.simulators.carla.actions import SetHandBrakeAction

PARKED_MODEL = "vehicle.nissan.patrol"
PED_MODEL = "walker.pedestrian.0001"

initLane = Uniform(*network.lanes)
ego_spawn_pt = new OrientedPoint on initLane.centerline
parked_spawn_pt = new OrientedPoint right of ego_spawn_pt by 3.5

require (distance from ego_spawn_pt to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The parked vehicle is placed 25 m ahead; the pedestrian hides 4.0 m behind it on the right, stepping out at the worst moment for the slow-moving ego.

param PARKED_DIST = 25
param PED_DIST_FROM_CAR = 4.0

parked_spot = new OrientedPoint following roadDirection from parked_spawn_pt for globalParameters.PARKED_DIST

ped_ref_spot = new OrientedPoint following roadDirection from parked_spot for globalParameters.PED_DIST_FROM_CAR
ped_spawn_pt = new OrientedPoint right of ped_ref_spot by 0.5

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

parked_car = new Car at parked_spot offset by (0, 0, 0.5),
    with blueprint PARKED_MODEL,
    with behavior ParkedBehavior()

ped = new Pedestrian at ped_spawn_pt offset by (0, 0, 1),
    with blueprint PED_MODEL,
    with regionContainedIn None,
    with behavior CrossAndFreeze(ego, globalParameters.PED_SPEED, globalParameters.PED_WALK_DURATION)
