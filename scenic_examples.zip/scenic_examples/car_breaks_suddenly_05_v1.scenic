# Scenario: Ego approaches at a fixed high speed and encounters a fully stationary adversarial truck stalled very close ahead, demanding an extremely urgent emergency braking response with almost no available stopping distance.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial truck holds maximum brake force of 1.0 for the entire scenario duration, remaining completely stationary; the large vehicle silhouette and maximum brakes create an immovable obstacle with a significant visual footprint.
param BRAKE_FORCE = 1.0

behavior AdvBehavior():
    while True:
        take SetBrakeAction(globalParameters.BRAKE_FORCE)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection and runs at a fixed high approach speed of 20 m/s to minimise the effective stopping distance to the stalled truck.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=20)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial truck spawns at a static very close distance of 15 m ahead; combined with the high ego approach speed of 20 m/s this produces the most demanding emergency stop challenge in this scenario family.
param GEO_Y_DISTANCE = 15
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with blueprint "vehicle.carlamotors.carlacola",
    with behavior AdvBehavior()
