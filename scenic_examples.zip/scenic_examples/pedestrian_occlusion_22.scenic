# Scenario: A parked truck on the right shoulder occludes a very slow elderly pedestrian who drifts leftward into the ego's path at a moderate trigger distance, creating a prolonged lane-blocking event that tests sustained yielding from the ego.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.tesla.model3"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Pedestrian waits on the right side and shuffles leftward at 1.2 m/s once ego reaches 16 m; the very slow leftward gait keeps the pedestrian blocking the lane well beyond the initial trigger event.

param PED_SPEED = 1.2
param TRIGGER_DIST = 16

behavior CrossingWalk(target_speed):
    while True:
        take SetWalkingDirectionAction(self.heading), SetWalkingSpeedAction(target_speed)

behavior PedestrianOcclusionBehavior(target_ego):
    while (distance from target_ego to self) > globalParameters.TRIGGER_DIST:
        wait
    do CrossingWalk(target_speed=globalParameters.PED_SPEED)

behavior ParkedBehavior():
    take SetBrakeAction(1.0)
    take SetHandBrakeAction(True)

# 3. ROAD GEOMETRY
# Straight lane in Town05 clear of intersections; ego cruises at 10 m/s toward the right-side truck at a slightly varied forward distance.

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=10)
require (distance to intersection) > 40

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Truck parked 22 m ahead on the right shoulder; the very slow pedestrian hides behind it and drifts leftward, occupying the lane far longer than a normally-paced pedestrian would.

param OCCLUDER_DIST = 22
param SIDE_OFFSET = 3.5

truck_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.OCCLUDER_DIST

occluder_truck = new Truck at truck_spot offset by (globalParameters.SIDE_OFFSET, 0, 0.5),
    with behavior ParkedBehavior()

ped_spawn = new OrientedPoint at (0.5, 4.0) relative to occluder_truck,
    facing -90 deg relative to occluder_truck

bad_pedestrian = new Pedestrian at ped_spawn,
    with regionContainedIn None,
    with behavior PedestrianOcclusionBehavior(ego)

require (distance from bad_pedestrian to occluder_truck) > 1
