# Scenario: Ego vehicle is driving on a straight road; the adversarial pedestrian crosses from the right front but is triggered very late and stops almost directly under the ego. Reduced trigger and stop distances create the minimum-margin crossing scenario.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian does not begin crossing until the ego is only 12 m away, then walks at 1.8 m/s and freezes just 2 m in front of the ego; the late trigger combined with the minimal stop distance leaves the ego almost no braking margin before the pedestrian enters the path.

param EGO_SPEED = 10
param PED_SPEED = 1.8
param TRIGGER_DIST = 12
param STOP_DIST = 2

behavior PedestrianCrossAndStopBehavior(ped_speed, trigger_dist, stop_dist):
    while (distance from self to ego) > trigger_dist:
        wait
    while True:
        if (distance from self to ego) <= stop_dist:
            take SetWalkingSpeedAction(0)
            break
        else:
            take SetWalkingDirectionAction(self.heading)
            take SetWalkingSpeedAction(ped_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 60 m from any intersection; the ego spawns at the lane centreline and the pedestrian reference point is placed 22 m ahead; the 12 m trigger distance means most of that gap is closed before the crossing begins.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 60


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The pedestrian spawns 22 m ahead and 3.8 m to the right; the late 12 m trigger and 2 m stop distance represent the worst-case crossing scenario where the ego has the absolute minimum space to decelerate before impact.

param START_DISTANCE = 22
param LATERAL_OFFSET = 3.8

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

adv_spot_road = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE
ped_spawn = new OrientedPoint right of adv_spot_road by globalParameters.LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to adv_spot_road.heading,
    with regionContainedIn None,
    with behavior PedestrianCrossAndStopBehavior(globalParameters.PED_SPEED, globalParameters.TRIGGER_DIST, globalParameters.STOP_DIST)

require ped not in network.drivableRegion
