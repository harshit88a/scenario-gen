# Scenario: A parked van occludes a brisk pedestrian who bursts into the moderately fast ego's path at an extremely close trigger distance, producing the most acute braking demand in the van-occlusion scenario family.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.tesla.model3"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Pedestrian waits behind the van and crosses at 2.5 m/s once ego reaches only 10 m; the very short trigger distance paired with fast crossing speed creates an emergency stop event.

param PED_SPEED = 2.5
param TRIGGER_DIST = 10

behavior CrossingWalk(target_speed):
    while True:
        take SetWalkingDirectionAction(self.heading), SetWalkingSpeedAction(target_speed)

behavior PedestrianOcclusionBehavior(target_ego):
    while (distance from target_ego to self) > globalParameters.TRIGGER_DIST:
        wait
    do CrossingWalk(target_speed=globalParameters.PED_SPEED)

behavior ParkedBehavior():
    take SetBrakeAction(1.0)
    take SetHandBrakeAction(True)

# 3. ROAD GEOMETRY
# Straight lane in Town05 clear of intersections; ego cruises at 12 m/s, raising the urgency of the close-trigger fast-crossing event.

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=12)
require (distance to intersection) > 40

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Parked van placed 22 m ahead at a fixed -3.5 m side offset; the near placement and close trigger give the ego minimal perception time before the pedestrian occupies the lane.

param OCCLUDER_DIST = 22
param SIDE_OFFSET = -3.5

van_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.OCCLUDER_DIST

occluder_van = new Car at van_spot offset by (globalParameters.SIDE_OFFSET, 0, 0.5),
    with blueprint "vehicle.ford.ambulance",
    with behavior ParkedBehavior()

ped_spawn = new OrientedPoint at (-0.5, 4.0) relative to occluder_van,
    facing 90 deg relative to occluder_van

bad_pedestrian = new Pedestrian at ped_spawn,
    with regionContainedIn None,
    with behavior PedestrianOcclusionBehavior(ego)

require (distance from bad_pedestrian to occluder_van) > 1
