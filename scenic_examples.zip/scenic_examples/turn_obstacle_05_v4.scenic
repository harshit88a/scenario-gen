# Scenario: The ego vehicle is turning right at a 4-way intersection at high fixed speed; the adversarial motorcyclist crosses at a fixed medium speed with a tight braking threshold, leaving almost no gap between the blocking position and the ego's fast-approaching turning arc.

# 1. MAP AND MODEL CONFIGURATION

param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial motorcyclist idles until the ego reaches a static trigger of 10 m from the stop point, then drives at a fixed medium speed of 9 m/s and brakes within a tight static threshold of 2 m of the stop point; the ego's fixed fast speed of 10 m/s means both agents converge on the conflict zone at very close temporal spacing.

param EGO_SPEED = 10
param ADV_SPEED = 9
param SAFETY_DIST = Range(8, 14)
param BRAKE_INTENSITY = 1.0
param ADV_STOP_THRESHOLD = 2
param EGO_TRIGGER_DIST = 10
param ADV_LATERAL_OFFSET = Range(5, 8)

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.EGO_SPEED, trajectory=trajectory)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

behavior AdversaryBehavior(stop_point):
    while (distance from ego to stop_point) > globalParameters.EGO_TRIGGER_DIST:
        take SetThrottleAction(0), SetBrakeAction(0)
    try:
        while True:
            take SetThrottleAction(1.0), SetSteerAction(0.0)
    interrupt when (distance from self to stop_point) < globalParameters.ADV_STOP_THRESHOLD:
        while True:
            take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        wait

# 3. ROAD GEOMETRY
# Only 4-way intersections are considered so the full perpendicular crossing geometry is guaranteed; right-turn maneuvers are extracted and sampled uniformly across all 4-way sites in Town05 to maximise spatial diversity.

ADV_MODEL = "vehicle.harley-davidson.low_rider"

def get_right_turn_maneuvers(intersections):
    maneuvers = []
    for intersec in intersections:
        right_turns = filter(lambda m: m.type == ManeuverType.RIGHT_TURN, intersec.maneuvers)
        for rt in right_turns:
            maneuvers.append(rt)
    return maneuvers

four_way_intersections = filter(lambda i: i.is4Way, network.intersections)
valid_maneuvers = get_right_turn_maneuvers(four_way_intersections)

require len(valid_maneuvers) > 0

ego_maneuver = Uniform(*valid_maneuvers)
ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]

connecting_pts = ego_maneuver.connectingLane.centerline.points
mid_idx = int(len(connecting_pts) / 2)
intersection_stop_pt = new OrientedPoint at connecting_pts[mid_idx]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The ego spawns at a static 15 m to reduce its pre-turn buffer at high speed; the motorcyclist spawns with a sampled lateral offset of 5–8 m from the stop point, ensuring the tight 2 m brake threshold produces a close blocking position relative to the fast ego.

param EGO_DIST_TO_INTERSECTION = 15

ego_anchor = new OrientedPoint at ego_maneuver.startLane.centerline.points[-1]
ego_spawn_pt = new OrientedPoint following roadDirection from ego_anchor for -globalParameters.EGO_DIST_TO_INTERSECTION

adv_spawn_pt = new OrientedPoint at intersection_stop_pt offset by (globalParameters.ADV_LATERAL_OFFSET, 0, 0)

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Car at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with regionContainedIn None,
    facing toward intersection_stop_pt,
    with behavior AdversaryBehavior(intersection_stop_pt)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 80
