# Scenario: Ego vehicle approaches a 4-way intersection at 10 m/s; the adversarial car from the right creeps at 3 m/s, blocking multiple lanes. The ego detects it at 28 m and performs a lane change to bypass.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversary creeps at 3 m/s through the intersection. Ego detects it at 28 m and performs a left lane change. Safety distance of 18 m.

param EGO_SPEED = 10
param ADV_SPEED = 3
param SAFETY_DIST = 18
param BRAKE_INTENSITY = 1.0
param LANE_CHANGE_TRIGGER_DIST = 28

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        if withinDistanceToTrafficLight(adversary, 100):
            setClosestTrafficLightStatus(adversary, "green")
        wait

behavior AdversaryBehavior(trajectory):
    do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.ADV_SPEED)

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.EGO_SPEED)
    interrupt when (distance from self to adversary) < globalParameters.LANE_CHANGE_TRIGGER_DIST and (adversary.speed < 3):
        adjacentLane = self.laneSection.laneToLeft
        do LaneChangeBehavior(laneSectionToSwitch=adjacentLane, is_oppositeTraffic=False, target_speed=globalParameters.EGO_SPEED)

# 3. ROAD GEOMETRY
# A four-way intersection where the ego proceeds straight and the adversary enters from the right also going straight at a crawl, occupying the ego's intended path and forcing the ego to shift to an adjacent lane to pass.

ADV_MODEL = "vehicle.tesla.model3"

fourWayIntersections = filter(lambda i: i.is4Way, network.intersections)
intersec = Uniform(*fourWayIntersections)

ego_maneuvers = filter(lambda i: i.type == ManeuverType.STRAIGHT, intersec.maneuvers)
ego_maneuver = Uniform(*ego_maneuvers)
ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]

adv_maneuvers = filter(lambda i: i.type == ManeuverType.STRAIGHT, ego_maneuver.conflictingManeuvers)
adv_maneuver = Uniform(*adv_maneuvers)
adv_trajectory = [adv_maneuver.startLane, adv_maneuver.connectingLane, adv_maneuver.endLane]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Ego spawns 18 m from intersection; adversary spawns 16 m back on the right conflicting lane for a slightly earlier slow-block.

param EGO_DIST_TO_INTERSECTION = 18
param ADV_DIST_TO_INTERSECTION = 16

ego_init_pt = new OrientedPoint in ego_maneuver.startLane.centerline
adv_init_pt = new OrientedPoint in adv_maneuver.startLane.centerline

ego_spawn_pt = new OrientedPoint following roadDirection from ego_init_pt for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_init_pt for -globalParameters.ADV_DIST_TO_INTERSECTION

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Car at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with behavior AdversaryBehavior(adv_trajectory)

require (adversary.position relative to ego_spawn_pt).x > 0
require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 100
