# Scenario: The adversarial leading car crawls at the minimum fixed slow speed to maximally lure the ego in before surging to the maximum fixed fast speed, producing the largest possible speed differential at the tightest trigger and spawn distances.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial car crawls at a fixed minimum slow speed of 3 m/s to draw the ego into close proximity, then surges to a fixed maximum fast speed of 40 m/s the instant the ego closes to a static trigger distance of 10 m, creating the maximum possible speed differential event.
param ADV_SLOW_SPEED = 3
param ADV_FAST_SPEED = 40
param ADV_DISTANCE = 10

behavior AdvBehavior(target_ego):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SLOW_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    do FollowLaneBehavior(target_speed=globalParameters.ADV_FAST_SPEED)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection so the crawl-and-surge speed differential is evaluated in an open straight-road context.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial car spawns at a static close distance of 12 m ahead of the ego; the minimum slow crawl and close spawn ensure the trigger fires very quickly after scenario start, giving the ego almost no time before the surge.
param GEO_Y_DISTANCE = 12
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior AdvBehavior(ego)
