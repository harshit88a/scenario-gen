# Scenario: Slow ego vehicle (10 m/s) attempts a right lane change to bypass a very slow lead (3 m/s); the fast adversary (15 m/s) dramatically slows to 5 m/s at 20 m proximity, creating a sudden surprise double blockade.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Slow ego (10 m/s). Fast adversary starts at 15 m/s then drops sharply to 5 m/s at 20 m proximity, creating a dramatic speed change surprise. Ego brakes at 12 m.

param EGO_SPEED = 10
param SLOW_SPEED = 3
param ADV_INIT_SPEED = 15
param ADV_MATCH_SPEED = 5
param TRIGGER_DIST = 25
param SAFETY_DIST = 12
param MATCH_TRIGGER_DIST = 20

behavior SlowVehicleBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.SLOW_SPEED)

behavior AdversaryBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ADV_INIT_SPEED) until \
        (distance to ego) < globalParameters.MATCH_TRIGGER_DIST
    do FollowLaneBehavior(target_speed=globalParameters.ADV_MATCH_SPEED)

behavior EgoBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance to slowVehicle) < globalParameters.TRIGGER_DIST

    rightSection = network.laneSectionAt(self)._laneToRight

    try:
        do LaneChangeBehavior(laneSectionToSwitch=rightSection, target_speed=globalParameters.EGO_SPEED)
    interrupt when (distance to adversary) < globalParameters.SAFETY_DIST:
        take SetBrakeAction(0.8)

    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED)

# 3. ROAD GEOMETRY
# A multi-lane straight road where the ego and slow vehicle share the left lane, and the adversarial car starts ahead in the right adjacent lane before slowing to block the lane change.

valid_lane_pairs = []
for lane in network.lanes:
    for sec in lane.sections:
        right_sec = sec._laneToRight
        if right_sec is not None:
            valid_lane_pairs.append((lane, right_sec.lane))
            break

selected_pair = Uniform(*valid_lane_pairs)
initLane = selected_pair[0]
rightLane = selected_pair[1]

spawnPt = new OrientedPoint on initLane.centerline
rightPt = new OrientedPoint on rightLane.centerline

require (distance from spawnPt to intersection) > 80
require (distance from rightPt to intersection) > 80

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Slow vehicle spawns 22 m ahead; adversary spawns 26 m ahead in the right lane with a large initial speed gap for dramatic deceleration.

param SLOW_DIST = 22
param ADV_DIST = 26

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior()

slow_spot = new OrientedPoint following roadDirection from spawnPt for globalParameters.SLOW_DIST
slowVehicle = new Car at slow_spot offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior SlowVehicleBehavior()

adv_spot = new OrientedPoint following roadDirection from rightPt for globalParameters.ADV_DIST
adversary = new Car at adv_spot offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior AdversaryBehavior()

require (distance from slowVehicle to intersection) > 50
require (distance from adversary to intersection) > 40
