# Scenario: Ego approaches at a fixed slow speed and encounters a fully stationary adversarial vehicle stalled far ahead, providing a longer detection window but still demanding a controlled emergency stop before reaching the obstacle.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial vehicle holds maximum brake force of 1.0 for the entire scenario duration, remaining completely stationary; at the ego's slow approach speed the vehicle is detectable from further away, testing the ego's low-speed emergency response.
param BRAKE_FORCE = 1.0

behavior AdvBehavior():
    while True:
        take SetBrakeAction(globalParameters.BRAKE_FORCE)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection and runs at a fixed slow approach speed of 10 m/s to provide longer time-to-contact while still requiring a decisive emergency stop.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=10)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial vehicle spawns at a static far distance of 30 m ahead; the slow ego approach speed and long gap together test the ego's ability to detect and respond to a stationary obstacle at extended range.
param GEO_Y_DISTANCE = 30
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior AdvBehavior()
