# Scenario: Ego vehicle is driving on a straight road; the adversarial pedestrian crosses from the right front at slow speed and stops in front of the ego from a farther spawn position. Static parameters sampled at the upper bound of the original Range distributions.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian waits until the ego closes to 18 m then walks leftward into the lane at 1.8 m/s and freezes 4 m in front of the ego; spawned 28 m ahead at 4.5 m lateral offset, the longer approach gives the ego slightly more time but the pedestrian crosses from further right, increasing the road coverage required.

param EGO_SPEED = 10
param PED_SPEED = 1.8
param TRIGGER_DIST = 18
param STOP_DIST = 4

behavior PedestrianCrossAndStopBehavior(ped_speed, trigger_dist, stop_dist):
    while (distance from self to ego) > trigger_dist:
        wait
    while True:
        if (distance from self to ego) <= stop_dist:
            take SetWalkingSpeedAction(0)
            break
        else:
            take SetWalkingDirectionAction(self.heading)
            take SetWalkingSpeedAction(ped_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 60 m from any intersection; the ego spawns at the lane centreline and the pedestrian reference point is placed 28 m ahead.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 60


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The pedestrian spawns 28 m ahead and 4.5 m to the right of the ego's lane centreline; the upper-bound lateral offset means the pedestrian must cross more road width before reaching the ego's path, extending the crossing window.

param START_DISTANCE = 28
param LATERAL_OFFSET = 4.5

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

adv_spot_road = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE
ped_spawn = new OrientedPoint right of adv_spot_road by globalParameters.LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to adv_spot_road.heading,
    with regionContainedIn None,
    with behavior PedestrianCrossAndStopBehavior(globalParameters.PED_SPEED, globalParameters.TRIGGER_DIST, globalParameters.STOP_DIST)

require ped not in network.drivableRegion
