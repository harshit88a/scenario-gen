# Scenario: Ego drives straight; leading car travels at a fixed high speed, then applies only partial braking at a far trigger distance, producing a gradual deceleration that still closes the gap dangerously as the ego continues at full approach speed.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial car travels at a fixed high speed of 10 m/s and applies a partial brake force of 0.5 once the ego reaches the static far trigger distance of 20 m, creating a drawn-out deceleration event that lures the ego into a shrinking gap.
param ADV_SPEED = 10
param ADV_DISTANCE = 20
param BRAKE_FORCE = 0.5

behavior AdvBehavior(target_ego, brake_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetBrakeAction(brake_intensity)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection to maintain an unobstructed straight-road braking scenario.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial car spawns at a static far distance of 30 m ahead of the ego; the combination of high ADV speed and far trigger means the gap closes over a longer observable window before the partial brake engages.
param GEO_Y_DISTANCE = 30
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior AdvBehavior(ego, globalParameters.BRAKE_FORCE)
