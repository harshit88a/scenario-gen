# Scenario: Ego vehicle is driving on a straight road; the adversarial pedestrian emerges from a driveway on the left with a late trigger, stops briefly, then walks at a steep diagonal directly toward the ego's future path. Reduced trigger distance and a steeper diagonal angle create the most challenging tracking scenario.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian idles until the ego closes to only 14 m, then emerges at 3.0 m/s and stops for just 15 ticks before resuming a steep 70-degree diagonal walk; the late trigger leaves the ego very little time to react, and the steep diagonal places the pedestrian continuously in the predicted path of the ego.

param EGO_SPEED = 10
param PED_INITIAL_SPEED = 3.0
param PED_DIAGONAL_SPEED = 1.5
param TRIGGER_DIST = 14
param STOP_DURATION = 15
param DIAGONAL_ANGLE = 70

behavior PedestrianDrivewayDiagonalBehavior(initial_speed, diagonal_speed, trigger_dist, stop_duration, diagonal_angle):
    while (distance from self to ego) > trigger_dist:
        take SetWalkingSpeedAction(0)
    while (distance from self to ego) > (trigger_dist - 6):
        take SetWalkingDirectionAction(self.heading)
        take SetWalkingSpeedAction(initial_speed)
    for _ in range(stop_duration):
        take SetWalkingSpeedAction(0)
    diag_heading = self.heading + diagonal_angle deg
    while True:
        take SetWalkingDirectionAction(diag_heading)
        take SetWalkingSpeedAction(diagonal_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 70 m from any intersection; the driveway reference is placed 20 m ahead; the 14 m trigger means the ego has closed most of that gap before the pedestrian moves.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 70
require (distance from spawnPt to initLane.centerline[-1]) > 50


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The pedestrian spawns 20 m ahead and 4.5 m to the left with a 1.2 m setback; the late 14 m trigger, brief 15-tick stop, and steep 70-degree diagonal angle produce the most evasive pedestrian trajectory, keeping the pedestrian in the ego's projected path longer than the base scenario.

param START_DISTANCE = 20
param LATERAL_OFFSET = 4.5
param DRIVEWAY_SETBACK = 1.2

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

driveway_ref = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE

ped_spawn = new OrientedPoint left of driveway_ref by globalParameters.LATERAL_OFFSET,
    facing driveway_ref.heading

ped = new Pedestrian at ped_spawn offset by (-globalParameters.DRIVEWAY_SETBACK, 0, 1),
    facing 270 deg relative to driveway_ref.heading,
    with regionContainedIn None,
    with behavior PedestrianDrivewayDiagonalBehavior(
        globalParameters.PED_INITIAL_SPEED,
        globalParameters.PED_DIAGONAL_SPEED,
        globalParameters.TRIGGER_DIST,
        globalParameters.STOP_DURATION,
        globalParameters.DIAGONAL_ANGLE
    )

require ped not in network.drivableRegion
