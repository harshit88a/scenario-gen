# Scenario: Three construction cones are fanned across the lane width at a sampled forward distance
# with a sampled lateral spread, creating variable-width blockades that probe how the ego responds
# when the navigable gap changes between simulation runs.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Three cones fully static; start distance and lateral spread are sampled to vary blockade width
param DEBRIS_START_DIST = Range(20, 30)
param LATERAL_SPREAD = Range(1.2, 2.0)

behavior StaticObjectBehavior():
    while True:
        wait

# 3. ROAD GEOMETRY
# Ego cruises straight toward the sampled cone blockade at the same fixed reference speed
EGO_SPEED = 13

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 1.0),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=EGO_SPEED)

require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Left, center, and right cones co-located in depth but spread at a sampled lateral distance
debris_spot_center = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DEBRIS_START_DIST

debris_center = new Prop at debris_spot_center offset by (0, 0, 0),
    with blueprint "static.prop.constructioncone",
    with physics True,
    with behavior StaticObjectBehavior()

debris_left = new Prop at debris_spot_center offset by (globalParameters.LATERAL_SPREAD, 0, 0),
    with blueprint "static.prop.constructioncone",
    with physics True,
    with behavior StaticObjectBehavior()

debris_right = new Prop at debris_spot_center offset by (-globalParameters.LATERAL_SPREAD, 0, 0),
    with blueprint "static.prop.constructioncone",
    with physics True,
    with behavior StaticObjectBehavior()

terminate when (distance from ego to EgoSpawnPt) > 70
