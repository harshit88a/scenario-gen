# Scenario: Ego vehicle drives straight and must brake urgently when a slow-moving pedestrian steps off the right shoulder at a close trigger distance, leaving the ego very little stopping margin.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial pedestrian crosses slowly at 1.5 m/s and is triggered only 12 m from the ego, making the narrow reaction window especially dangerous at low pedestrian speed.

from scenic.simulators.carla.behaviors import CrossingBehavior

param EGO_SPEED = 10
param PED_SPEED = 1.5
param TRIGGER_DIST = 12

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)

# 3. ROAD GEOMETRY
# A straight road well away from any intersection, giving the ego no contextual warning of a pedestrian hazard.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The pedestrian is placed 20 m ahead on the front-right shoulder at a tight 3.5 m lateral offset, stepping out at the worst moment during the ego's approach.

param START_DISTANCE = 20
param LATERAL_OFFSET = 3.5

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

adv_spot_road = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE
ped_spawn = new OrientedPoint right of adv_spot_road by globalParameters.LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to adv_spot_road.heading,
    with regionContainedIn None,
    with behavior CrossingBehavior(ego, globalParameters.PED_SPEED, globalParameters.TRIGGER_DIST)

require ped not in network.drivableRegion
