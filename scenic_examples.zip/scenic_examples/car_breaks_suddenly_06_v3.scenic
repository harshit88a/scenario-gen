# Scenario: An adversarial vehicle in the adjacent left lane travels at a fixed medium speed and cuts aggressively into the ego's lane with a higher steer intensity at a mid-range trigger distance, producing a more violent lane change than the baseline that demands a sharper ego avoidance response.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial vehicle follows its adjacent left lane at a fixed medium speed of 20 m/s and applies a static aggressive steer intensity of 0.7 into the ego's lane at the static mid-range trigger distance of 15 m; the higher steer value makes the lateral intrusion faster and more severe than the baseline.
param ADV_SPEED = 20
param ADV_DISTANCE = 15
param STEER_INTENSITY = 0.7

behavior AdvBehavior(target_ego, steer_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetSteerAction(steer_intensity)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection to isolate the aggressive cut-in evaluation from intersection-related complexities.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial car spawns at a static mid distance of 22 m ahead and one lane-width to the left of the ego; the medium approach speed and 15 m trigger give the ego a brief but observable lead-up before the aggressive 0.7 steer cut-in fires.
param GEO_Y_DISTANCE = 22
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (-3.5, 0, 0.5),
    with behavior AdvBehavior(ego, globalParameters.STEER_INTENSITY)
