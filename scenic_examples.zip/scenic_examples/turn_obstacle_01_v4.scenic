# Scenario: The ego vehicle turns left at high fixed speed; a Yamaha YZF motorcyclist on the right front matches the ego's urgency with a medium-high fixed approach speed then brakes sharply at the intersection edge, creating a high-tempo false-crossing confusion event.

# 1. MAP AND MODEL CONFIGURATION

param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial Yamaha YZF travels at a fixed 9 m/s toward the intersection and triggers a full brake at a static 5 m from the lane endpoint; the ego's fixed fast turn speed of 10 m/s means both agents reach the conflict zone nearly simultaneously, maximising surprise.

param EGO_SPEED = 10
param ADV_SPEED = 9
param SAFETY_DIST = Range(8, 14)
param BRAKE_INTENSITY = 1.0
param ADV_BRAKE_TRIGGER_DIST = 5

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.EGO_SPEED, trajectory=trajectory)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

behavior AdversaryBehavior(trajectory, brake_point):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.ADV_SPEED, trajectory=trajectory)
    interrupt when (distance from self to brake_point) < globalParameters.ADV_BRAKE_TRIGGER_DIST:
        while True:
            take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        wait

# 3. ROAD GEOMETRY
# All intersections in the network are considered to maximise scenario diversity; left-turn and conflicting straight maneuver pairs are extracted and sampled uniformly so the Yamaha YZF's approach angle varies across simulation runs.

ADV_MODEL = "vehicle.yamaha.yzf"

def get_conflict_pairs(intersections):
    pairs = []
    for intersec in intersections:
        left_turns = filter(lambda m: m.type == ManeuverType.LEFT_TURN, intersec.maneuvers)
        for lt in left_turns:
            conflicts = filter(lambda c: c.type == ManeuverType.STRAIGHT, lt.conflictingManeuvers)
            for c in conflicts:
                pairs.append([lt, c])
    return pairs

all_intersections = network.intersections
valid_pairs = get_conflict_pairs(all_intersections)

require len(valid_pairs) > 0

selected_pair = Uniform(*valid_pairs)
ego_maneuver = selected_pair[0]
adv_maneuver = selected_pair[1]

ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]
adv_trajectory = [adv_maneuver.startLane, adv_maneuver.connectingLane, adv_maneuver.endLane]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Both agents spawn at identical static distances of 20 m from their respective intersection entry points so that the fast ego and the medium-high-speed adversary arrive at the conflict zone at the closest temporal alignment possible.

param EGO_DIST_TO_INTERSECTION = 20
param ADV_DIST_TO_INTERSECTION = 20

ego_anchor = new OrientedPoint at ego_maneuver.startLane.centerline.points[-1]
adv_anchor = new OrientedPoint at adv_maneuver.startLane.centerline.points[-1]

ego_spawn_pt = new OrientedPoint following roadDirection from ego_anchor for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_anchor for -globalParameters.ADV_DIST_TO_INTERSECTION

adv_brake_point = new OrientedPoint at adv_maneuver.startLane.centerline.points[-1]

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Motorcycle at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with behavior AdversaryBehavior(adv_trajectory, adv_brake_point)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 80
