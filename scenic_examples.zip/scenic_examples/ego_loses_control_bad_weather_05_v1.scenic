# Scenario: Four creasedbox02 props are scattered at fixed large intervals along the road,
# converting the baseline Range-sampled scatter to a fully deterministic long-range debris field
# to isolate sustained hazard-awareness performance at a known distance budget.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Four creasedbox02 props at fixed large intervals with fixed lateral offsets for full reproducibility
param DEBRIS_START_DIST = 25
param DEBRIS_GAP = 16

behavior StaticObjectBehavior():
    while True:
        wait

# 3. ROAD GEOMETRY
# Ego drives at the baseline reference speed across a long straight to encounter the fixed far debris
EGO_SPEED = 11

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 1.0),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=EGO_SPEED)

require (distance to intersection) > 80

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Four boxes placed at fixed large gaps with fixed alternating lateral offsets for reproducible scatter
debris_spot_1 = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DEBRIS_START_DIST

debris1 = new Prop at debris_spot_1 offset by (0.8, 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_2 = new OrientedPoint following roadDirection from debris_spot_1 for globalParameters.DEBRIS_GAP

debris2 = new Prop at debris_spot_2 offset by (-0.8, 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_3 = new OrientedPoint following roadDirection from debris_spot_2 for globalParameters.DEBRIS_GAP

debris3 = new Prop at debris_spot_3 offset by (0.8, 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_4 = new OrientedPoint following roadDirection from debris_spot_3 for globalParameters.DEBRIS_GAP

debris4 = new Prop at debris_spot_4 offset by (-0.8, 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

terminate when (distance from ego to EgoSpawnPt) > 100
