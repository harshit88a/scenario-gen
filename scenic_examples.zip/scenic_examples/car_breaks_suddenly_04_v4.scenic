# Scenario: The adversarial leading car crawls at a fixed slow speed while the ego approaches at a higher-than-baseline fixed speed, then the adversary surges to a large fast speed at a mid trigger, amplifying the speed differential hazard due to the ego's elevated entry speed.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial car crawls at a fixed slow speed of 4 m/s then surges to a fixed fast speed of 32 m/s at a static mid trigger distance of 12 m; the ego's elevated fixed speed of 20 m/s shortens the time-to-trigger significantly, increasing the severity of the speed differential event.
param ADV_SLOW_SPEED = 4
param ADV_FAST_SPEED = 32
param ADV_DISTANCE = 12

behavior AdvBehavior(target_ego):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SLOW_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    do FollowLaneBehavior(target_speed=globalParameters.ADV_FAST_SPEED)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection and runs at a fixed high approach speed to maximise the closing rate during the crawl phase.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=20)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial car spawns at a static mid distance of 20 m ahead of the ego; the ego's higher speed of 20 m/s closes the 20 m gap faster than baseline, bringing the 12 m trigger into play sooner and leaving less time before the surge.
param GEO_Y_DISTANCE = 20
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior AdvBehavior(ego)
