# Scenario: Ego vehicle is driving on a straight road; a pedestrian bursts from behind a vending machine at elevated speed and stops in front of the ego. Mid-range spawn distances with a faster dash speed to shorten the time from occlusion exit to lane entry.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian stands behind the vending machine 24 m ahead until the ego closes to 20 m, then bursts at an elevated 7.0 m/s and freezes 3.0 m in front of the ego; the higher dash speed means the pedestrian clears the machine and reaches the lane in almost half the time of the base scenario.

param EGO_SPEED = 10
param PED_DASH_SPEED = 7.0
param TRIGGER_DIST = 20
param STOP_DIST = 3.0

behavior PedestrianVendingMachineAmbushBehavior(dash_speed, trigger_dist, stop_dist):
    while (distance from self to ego) > trigger_dist:
        take SetWalkingSpeedAction(0)
    while True:
        if (distance from self to ego) <= stop_dist:
            take SetWalkingSpeedAction(0)
            break
        else:
            take SetWalkingDirectionAction(self.heading)
            take SetWalkingSpeedAction(dash_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 70 m from any intersection; the vending machine reference is placed 24 m ahead at a mid-range distance with the machine 4.0 m to the right and the pedestrian 4.7 m to the right.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 70
require (distance from spawnPt to initLane.centerline[-1]) > 50


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The vending machine sits 24 m ahead and 4.0 m right; the pedestrian hides 4.7 m right and 0.8 m rearward; the elevated 7.0 m/s dash speed is the primary augmentation, causing the pedestrian to cover the shoulder-to-lane distance in significantly less time than the base scenario.

param START_DISTANCE = 24
param VM_LATERAL_OFFSET = 4.0
param PED_HIDE_OFFSET = 0.8
param PED_LATERAL_OFFSET = 4.7

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

vm_ref = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE

vending_machine = new Prop right of vm_ref by globalParameters.VM_LATERAL_OFFSET,
    with blueprint "static.prop.vendingmachine",
    facing vm_ref.heading,
    with regionContainedIn None

ped_spawn = new OrientedPoint right of vm_ref by globalParameters.PED_LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (-globalParameters.PED_HIDE_OFFSET, 0, 1),
    facing 90 deg relative to vm_ref.heading,
    with regionContainedIn None,
    with behavior PedestrianVendingMachineAmbushBehavior(
        globalParameters.PED_DASH_SPEED,
        globalParameters.TRIGGER_DIST,
        globalParameters.STOP_DIST
    )

require ped not in network.drivableRegion
require vending_machine not in network.drivableRegion
