# Scenario: Pedestrian crossing from behind occlusion — a parked truck hides a pedestrian who jaywalks at a moderate speed and trigger distance with the truck at a midpoint placement, representing the median occlusion threat severity.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.tesla.model3"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Pedestrian waits behind the truck until ego is 14 m away, then walks at 2.0 m/s; midpoint speed and trigger distance produce a balanced but still dangerous reaction scenario.

param PED_SPEED = 2.0
param TRIGGER_DIST = 14

behavior CrossingWalk(target_speed):
    while True:
        take SetWalkingDirectionAction(self.heading), SetWalkingSpeedAction(target_speed)

behavior PedestrianOcclusionBehavior(target_ego):
    while (distance from target_ego to self) > globalParameters.TRIGGER_DIST:
        wait
    do CrossingWalk(target_speed=globalParameters.PED_SPEED)

behavior ParkedBehavior():
    take SetBrakeAction(1.0)
    take SetHandBrakeAction(True)

# 3. ROAD GEOMETRY
# Straight lane in Town05 clear of intersections; ego cruises at 10 m/s with the truck at a midpoint forward distance.

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=10)
require (distance to intersection) > 40

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Truck parked 25 m ahead on the left shoulder; pedestrian hides at the standard relative offset and emerges at the midpoint trigger.

param OCCLUDER_DIST = 25
param SIDE_OFFSET = -3.5

truck_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.OCCLUDER_DIST

occluder_truck = new Truck at truck_spot offset by (globalParameters.SIDE_OFFSET, 0, 0.5),
    with behavior ParkedBehavior()

ped_spawn = new OrientedPoint at (-0.5, 4.0) relative to occluder_truck,
    facing 90 deg relative to occluder_truck

bad_pedestrian = new Pedestrian at ped_spawn,
    with regionContainedIn None,
    with behavior PedestrianOcclusionBehavior(ego)

require (distance from bad_pedestrian to occluder_truck) > 1
