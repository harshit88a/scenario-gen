# Scenario: Ego vehicle drives straight and must brake hard when a fast-moving pedestrian darts from the right shoulder at a moderate trigger distance, compressing the time-to-collision despite the earlier warning.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial pedestrian crosses at 3.0 m/s and triggers at 18 m from the ego; the high crossing speed means the pedestrian occupies the lane faster than the ego expects.

from scenic.simulators.carla.behaviors import CrossingBehavior

param EGO_SPEED = 10
param PED_SPEED = 3.0
param TRIGGER_DIST = 18

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)

# 3. ROAD GEOMETRY
# A straight road well clear of intersections so no external cues warn the ego of the pedestrian threat.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The pedestrian is placed 25 m ahead to the front-right at a 4.0 m lateral offset, giving an apparent gap that the fast crossing speed eliminates quickly.

param START_DISTANCE = 25
param LATERAL_OFFSET = 4.0

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

adv_spot_road = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE
ped_spawn = new OrientedPoint right of adv_spot_road by globalParameters.LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to adv_spot_road.heading,
    with regionContainedIn None,
    with behavior CrossingBehavior(ego, globalParameters.PED_SPEED, globalParameters.TRIGGER_DIST)

require ped not in network.drivableRegion
