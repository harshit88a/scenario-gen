# Scenario: Two vehicles chained ahead trigger a cascading emergency brake at a barrel obstacle with a tighter fixed mid-to-front inter-vehicle gap, compressing the cascade propagation window to test whether a shorter inter-vehicle spacing increases rear-collision probability for the ego.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Both cars brake at a fixed trigger distance; obstacle blueprint swapped to barrel for profile comparison
param LEAD_SPEED = Range(10, 14)
param OBSTACLE_BRAKE_DIST = Range(10, 15)
param BRAKE_FORCE = 1.0

behavior LeadCarBehavior(target_obstacle, brake_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.LEAD_SPEED) until \
        (distance from target_obstacle to self) < globalParameters.OBSTACLE_BRAKE_DIST
    while True:
        take SetBrakeAction(brake_intensity)

# 3. ROAD GEOMETRY
# Ego drives at standard speed toward the tighter two-car chain on a straight lane
EGO_SPEED = 12

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=EGO_SPEED)

require (distance to intersection) > 80

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Mid-to-front gap is tightened to a fixed value; obstacle is a barrel instead of trash bin
param DIST_EGO_TO_MID = Range(10, 15)
param DIST_MID_TO_FRONT = 10
param DIST_FRONT_TO_OBSTACLE = Range(28, 38)

mid_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DIST_EGO_TO_MID

front_spot = new OrientedPoint following roadDirection from mid_spot for globalParameters.DIST_MID_TO_FRONT

obs_spot = new OrientedPoint following roadDirection from front_spot for globalParameters.DIST_FRONT_TO_OBSTACLE

obstacle = new Prop at obs_spot offset by (0, 0, 0.5),
    with blueprint "static.prop.barrel"

frontCar = new Car at front_spot offset by (0, 0, 0.5),
    with behavior LeadCarBehavior(obstacle, globalParameters.BRAKE_FORCE)

midCar = new Car at mid_spot offset by (0, 0, 0.5),
    with behavior LeadCarBehavior(frontCar, globalParameters.BRAKE_FORCE)

terminate when ego.speed < 0.1 and (distance to midCar) < 5
