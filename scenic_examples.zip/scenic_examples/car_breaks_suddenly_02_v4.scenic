# Scenario: Ego drives straight and encounters an adversarial vehicle at a moderate crawl speed for an extended phase before a full brake stop, giving the ego a deceptively long window of apparent safety before the sudden hard stop.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial vehicle travels at a fixed moderate crawl speed of 6 m/s for a static 5 seconds before applying maximum brake force of 1.0; the long crawl phase misleads the ego into reducing its alertness before the abrupt full stop.
param ADV_SPEED = 6
param BRAKE_FORCE = 1.0

behavior AdvBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) for 5 seconds
    while True:
        take SetBrakeAction(globalParameters.BRAKE_FORCE)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection to maintain the long crawl-and-brake dynamic in an unobstructed straight-road context.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial car spawns at a static far distance of 28 m ahead; the moderate crawl speed and 5-second window mean the ego travels a significant distance toward the adversary before the brake fires, maximising the deceptive lull effect.
param GEO_Y_DISTANCE = 28
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior AdvBehavior()
