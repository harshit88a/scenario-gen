# Scenario: The ego encounters a parked car blocking its lane and uses the opposite lane to bypass. The oncoming car begins at a higher initial speed (8 m/s) and surges to maximum acceleration speed (20 m/s) once the ego commits to the opposing lane. Distances sampled at upper bounds, providing wider initial separation that the aggressive acceleration quickly collapses.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The parked car remains stationary in the ego's lane. The oncoming car initially travels at 8 m/s and surges to 20 m/s once the ego enters the opposing lane within ACCEL_TRIGGER_DIST. The higher acceleration multiplies closing speed, giving the ego very little time to complete the return lane change within SAFETY_DIST and BRAKE_THRESHOLD.

param EGO_SPEED = 10
param ONCOMING_INIT_SPEED = 8
param ONCOMING_ACCEL_SPEED = 20
param BYPASS_TRIGGER_DIST = 20
param ACCEL_TRIGGER_DIST = 30
param SAFETY_DIST = 12
param BRAKE_THRESHOLD = 8

behavior ParkedCarBehavior():
    take SetSpeedAction(0)

behavior OncomingBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ONCOMING_INIT_SPEED) until \
        (distance to ego) < globalParameters.ACCEL_TRIGGER_DIST
    do FollowLaneBehavior(target_speed=globalParameters.ONCOMING_ACCEL_SPEED)

behavior EgoBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance to parkedCar) < globalParameters.BYPASS_TRIGGER_DIST

    leftSection = network.laneSectionAt(self)._laneToLeft

    try:
        do LaneChangeBehavior(laneSectionToSwitch=leftSection, target_speed=globalParameters.EGO_SPEED)
    interrupt when (distance to oncomingCar) < globalParameters.SAFETY_DIST:
        take SetBrakeAction(0.9)

    try:
        do LaneChangeBehavior(laneSectionToSwitch=network.laneSectionAt(self)._laneToRight,
                              target_speed=globalParameters.EGO_SPEED)
    interrupt when (distance to oncomingCar) < globalParameters.BRAKE_THRESHOLD:
        take SetBrakeAction(1.0)

    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED)


# 3. ROAD GEOMETRY
# A two-way road where the ego and parked car share one lane direction and the oncoming car occupies the adjacent opposite-direction lane. Valid ego and oncoming lane pairs are identified by checking for a left neighbour, ensuring the oncoming lane runs antiparallel to the ego lane.

valid_lane_pairs = []
for lane in network.lanes:
    for sec in lane.sections:
        left_sec = sec._laneToLeft
        if left_sec is not None:
            valid_lane_pairs.append((lane, left_sec.lane))
            break

selected_pair = Uniform(*valid_lane_pairs)
egoLane = selected_pair[0]
oncomingLane = selected_pair[1]

spawnPt = new OrientedPoint on egoLane.centerline
oncomingPt = new OrientedPoint on oncomingLane.centerline

require (distance from spawnPt to intersection) > 90
require (distance from oncomingPt to intersection) > 90


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The parked car is placed at the upper-bound distance directly ahead in the ego's lane. The oncoming car is placed at the upper-bound distance in the opposing lane, giving an apparent wide margin that the high acceleration quickly eliminates, forcing the ego into a genuine last-second decision.

param PARKED_DIST = 26
param ONCOMING_DIST = 50

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior()

parked_spot = new OrientedPoint following roadDirection from spawnPt for globalParameters.PARKED_DIST
parkedCar = new Car at parked_spot offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior ParkedCarBehavior()

oncoming_spot = new OrientedPoint following roadDirection from oncomingPt for globalParameters.ONCOMING_DIST
oncomingCar = new Car at oncoming_spot offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior OncomingBehavior()

require (distance from parkedCar to intersection) > 60
require (distance from oncomingCar to intersection) > 40
