# Scenario: The ego vehicle is turning right at an intersection; the adversarial pedestrian waits idle until the ego is very close to the stop point, then crosses slowly and freezes just inside the turning arc, forcing a last-moment braking reaction.

# 1. MAP AND MODEL CONFIGURATION

param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial pedestrian waits at a static trigger threshold of 8 m from the stop point; once the ego closes to that distance the pedestrian walks at a fixed slow speed of 1.2 m/s toward the stop point and freezes within 2.0 m, blocking the ego's right-turn exit at the last possible moment.

param EGO_SPEED = Range(6, 10)
param ADV_SPEED = 1.2
param SAFETY_DIST = Range(8, 14)
param BRAKE_INTENSITY = 1.0
param ADV_STOP_THRESHOLD = 2.0
param ADV_LATERAL_OFFSET = 4
param EGO_TRIGGER_DIST = 8

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.EGO_SPEED, trajectory=trajectory)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

behavior AdversaryBehavior(stop_point):
    while (distance from ego to stop_point) > globalParameters.EGO_TRIGGER_DIST:
        take SetWalkingSpeedAction(0)
    try:
        while True:
            take SetWalkingDirectionAction(self.heading), SetWalkingSpeedAction(globalParameters.ADV_SPEED)
    interrupt when (distance from self to stop_point) < globalParameters.ADV_STOP_THRESHOLD:
        while True:
            take SetWalkingSpeedAction(0)

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        wait

# 3. ROAD GEOMETRY
# All intersections in the network are considered; right-turn maneuvers are extracted and sampled uniformly so the slow late-triggered pedestrian scenario runs across all right-turn geometries available in Town05.

ADV_MODEL = "walker.pedestrian.0001"

def get_right_turn_maneuvers(intersections):
    maneuvers = []
    for intersec in intersections:
        right_turns = filter(lambda m: m.type == ManeuverType.RIGHT_TURN, intersec.maneuvers)
        for rt in right_turns:
            maneuvers.append(rt)
    return maneuvers

all_intersections = network.intersections
valid_maneuvers = get_right_turn_maneuvers(all_intersections)

require len(valid_maneuvers) > 0

ego_maneuver = Uniform(*valid_maneuvers)
ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]

intersection_stop_pt = new OrientedPoint at ego_maneuver.connectingLane.centerline.points[0]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The ego spawns at a static 20 m; the pedestrian spawns at a static lateral offset of 4 m to the left of the stop point, standing idle until the late trigger fires, then crossing slowly to freeze in the ego's right-turn path.

param EGO_DIST_TO_INTERSECTION = 20

ego_anchor = new OrientedPoint at ego_maneuver.startLane.centerline.points[-1]
ego_spawn_pt = new OrientedPoint following roadDirection from ego_anchor for -globalParameters.EGO_DIST_TO_INTERSECTION

adv_spawn_pt = new OrientedPoint at intersection_stop_pt offset by (globalParameters.ADV_LATERAL_OFFSET, 0, 0)

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Pedestrian at adv_spawn_pt,
    with blueprint ADV_MODEL,
    with regionContainedIn None,
    facing toward intersection_stop_pt,
    with behavior AdversaryBehavior(intersection_stop_pt)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 80
