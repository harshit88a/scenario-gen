# Scenario: Ego bypasses a lane-blocking parked car under threat from aggressive oncoming traffic (11 m/s), then encounters a fast-crossing jaywalking pedestrian requiring emergency braking. Adversarial sampling: high oncoming speed, closer spawn distances, and elevated pedestrian crossing speed heighten collision risk.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Ego follows its lane, detects the parked car and triggers bypass earlier due to reduced BYPASS_TRIGGER_DIST, changes into the opposing lane, clears the parked car, and returns to its original lane. The oncoming car closes the gap at an adversarially high speed of 11 m/s. The pedestrian dashes across at an elevated crossing speed of 1.8 m/s, leaving the ego minimal reaction time.

param ONCOMING_SPEED      = 11
param EGO_SPEED           = 10
param BYPASS_TRIGGER_DIST = 22
param BYPASS_CLEAR_DIST   = 15

behavior EgoBehavior(opposingSection, originalSection):
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance from self to parkedCar) < globalParameters.BYPASS_TRIGGER_DIST

    do LaneChangeBehavior(laneSectionToSwitch=opposingSection,
                          target_speed=globalParameters.EGO_SPEED)

    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance from self to parkedCar) > globalParameters.BYPASS_CLEAR_DIST

    do LaneChangeBehavior(laneSectionToSwitch=originalSection,
                          target_speed=globalParameters.EGO_SPEED)

    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED)

behavior OncomingCarBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ONCOMING_SPEED)

behavior JaywalkBehavior():
    do CrossingBehavior(ego, min_speed=1.8, threshold=15)


# 3. ROAD GEOMETRY
# Ego is placed on a straight lane. A left offset point identifies the opposing lane section for bypass, and a right offset from that point recovers the original lane section for return. Both are passed to EgoBehavior at construction time.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

leftCheckPt = new OrientedPoint left of spawnPt by 3.5
opposingSection = network.laneSectionAt(leftCheckPt)

rightCheckPt = new OrientedPoint right of leftCheckPt by 3.5
originalSection = network.laneSectionAt(rightCheckPt)

require opposingSection is not None
require getattr(opposingSection, 'lane', None) != initLane
require originalSection is not None

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(opposingSection, originalSection)

require (distance to intersection) > 80


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The parked car blocks the ego's lane. The oncoming car is placed closer to compress the bypass window at high speed. The pedestrian is placed closer to the parked car to minimise ego reaction time after the bypass maneuver. Adversarial distances tighten all safety margins simultaneously.

param DIST_EGO_TO_PARKED     = 26
param DIST_EGO_TO_PEDESTRIAN = 51
param DIST_EGO_TO_ONCOMING   = 57

parked_spot     = new OrientedPoint following roadDirection from spawnPt for globalParameters.DIST_EGO_TO_PARKED
pedestrian_spot = new OrientedPoint following roadDirection from spawnPt for globalParameters.DIST_EGO_TO_PEDESTRIAN
oncoming_spot   = new OrientedPoint following roadDirection from spawnPt for globalParameters.DIST_EGO_TO_ONCOMING

parkedCar = new Car at parked_spot offset by (0, 0, 0.5),
    with blueprint "vehicle.tesla.model3"

oncomingCar = new Car at oncoming_spot offset by (0, 0, 0.5),
    facing 180 deg relative to roadDirection,
    with behavior OncomingCarBehavior()

pedestrian = new Pedestrian at pedestrian_spot offset by (4, 0, 0.5),
    facing -90 deg relative to roadDirection,
    with regionContainedIn None,
    with behavior JaywalkBehavior()

require (distance from parkedCar to intersection) > 50

terminate when ego.speed < 0.5 and (distance from ego to pedestrian) < 5
