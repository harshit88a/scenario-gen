# Scenario: Ego vehicle (12 m/s) bypasses a slow adversary (5 m/s) by changing left; the adversary then accelerates to 15 m/s, blocking the return path, while a slow lead (6 m/s) in the target lane forces the ego to brake at 12 m.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversary starts slow at 5 m/s, accelerates to 15 m/s once ego clears. Lead at 6 m/s blocks the new lane. Ego triggered at 15 m, brakes at 12 m safety distance.

param EGO_SPEED = 12
param ADV_INIT_SPEED = 5
param ADV_END_SPEED = 15
param LEAD_SPEED = 6
param TRIGGER_DIST = 15
param SAFETY_DIST = 12

behavior AdversaryBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ADV_INIT_SPEED) until \
        (self.lane != ego.lane)
    do FollowLaneBehavior(target_speed=globalParameters.ADV_END_SPEED)

behavior LeadBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.LEAD_SPEED)

behavior EgoBehavior(target_section):
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance to adversary) < globalParameters.TRIGGER_DIST

    do LaneChangeBehavior(laneSectionToSwitch=target_section, target_speed=globalParameters.EGO_SPEED)

    try:
        do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED)
    interrupt when (distance to lead) < globalParameters.SAFETY_DIST:
        take SetBrakeAction(1.0)

# 3. ROAD GEOMETRY
# A multi-lane straight road where the ego bypasses a slow adversary by changing left, but the adversary then accelerates and a separate lead vehicle blocks the new lane.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 50

checkPt = new OrientedPoint left of spawnPt by 3.5
targetSection = network.laneSectionAt(checkPt)

require targetSection is not None
require targetSection.lane != initLane

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversary spawns 15 m ahead of ego in the original lane; lead spawns 35 m ahead in the target lane.

param ADV_DIST = 15
param LEAD_DIST = 35

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(targetSection)

adv_spot = new OrientedPoint following roadDirection from spawnPt for globalParameters.ADV_DIST
adversary = new Car at adv_spot offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior AdversaryBehavior()

lead_spot = new OrientedPoint following roadDirection from checkPt for globalParameters.LEAD_DIST
lead = new Car at lead_spot offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior LeadBehavior()

require (distance from adversary to intersection) > 20
require (distance from lead to intersection) > 20
