# Scenario: Fast ego vehicle (14 m/s) attempts a left lane change to avoid a slow lead (5 m/s); the adversary cuts back to the ego's original lane when the ego is 20 m away, blocking the return path at high speed.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Lead crawls at 5 m/s. Adversary follows at 12 m/s then cuts back at 20 m trigger. Ego brakes on 12 m safety distance.

param EGO_SPEED = 14
param ADV_SPEED = 12
param LEAD_SPEED = 5
param TRIGGER_DIST = 20
param SAFETY_DIST = 12

behavior LeadBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.LEAD_SPEED)

behavior AdversaryBehavior(origSection):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance to ego) < globalParameters.TRIGGER_DIST
    do LaneChangeBehavior(laneSectionToSwitch=origSection, target_speed=globalParameters.ADV_SPEED)
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED)

behavior EgoBehavior(targetSection):
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance to lead) < globalParameters.TRIGGER_DIST

    do LaneChangeBehavior(laneSectionToSwitch=targetSection, target_speed=globalParameters.EGO_SPEED)

    try:
        do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED)
    interrupt when (distance to adversary) < globalParameters.SAFETY_DIST:
        take SetBrakeAction(0.8)

# 3. ROAD GEOMETRY
# A multi-lane straight road where the ego's original lane and an adjacent target lane run in parallel.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 60

checkPt = new OrientedPoint left of spawnPt by 3.5
targetSection = network.laneSectionAt(checkPt)
origSection = network.laneSectionAt(spawnPt)

require targetSection is not None
require origSection is not None
require targetSection.lane != initLane

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Lead spawns 28 m ahead of ego; adversary spawns 14 m ahead in the target lane for a wider initial gap.

param LEAD_DIST = 28
param ADV_DIST = 14

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(targetSection)

lead_spot = new OrientedPoint following roadDirection from spawnPt for globalParameters.LEAD_DIST
lead = new Car at lead_spot offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior LeadBehavior()

adv_spot = new OrientedPoint following roadDirection from checkPt for globalParameters.ADV_DIST
adversary = new Car at adv_spot offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior AdversaryBehavior(origSection)

require (distance from lead to intersection) > 30
require (distance from adversary to intersection) > 30
