# Scenario: A Mercedes Sprinter van tailgater spawns behind the ego at a fixed high speed, charges aggressively before slamming on maximum brakes at a close trigger distance, presenting a large-vehicle rear-collision threat with maximum stopping force.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial Mercedes Sprinter charges at a fixed high speed of 30 m/s and applies maximum brake force of 1.0 at a static close trigger distance of 6 m from the ego; the large van's mass and maximum braking at close range creates a high-inertia near rear-end event.
param ADV_SPEED = 30
param ADV_DISTANCE = 6
param BRAKE_FORCE = 1.0

behavior AdvBehavior(target_ego, brake_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetBrakeAction(brake_intensity)

# 3. ROAD GEOMETRY
# The ego spawns ahead of the adversarial base point on a straight lane at a static gap of 40 m, giving the high-speed Sprinter a long approach run that makes the sudden close-range brake especially abrupt.
param GEO_Y_DISTANCE = 40
lane = Uniform(*network.lanes)
advBasePt = new OrientedPoint on lane.centerline
EgoSpawnPt = new OrientedPoint following roadDirection from advBasePt for globalParameters.GEO_Y_DISTANCE
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial Mercedes Sprinter spawns at the lane base point 40 m behind the ego; the high approach speed and 40 m gap together produce a long closure phase before the maximum brake fires at 6 m, leaving the ego no room to respond.
advAgent = new Car at advBasePt offset by (0, 0, 0.5),
    with blueprint "vehicle.mercedes.sprinter",
    with behavior AdvBehavior(ego, globalParameters.BRAKE_FORCE)
