# Scenario: A fast tailgater spawns behind the ego at minimum adversarial speed, charges to a very close trigger distance before slamming on maximum brakes, producing the tightest near-rear-end event at the lower edge of the tailgater speed range.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial tailgater charges at a fixed minimum speed of 22 m/s and applies maximum brake force of 1.0 only when within a static very close distance of 5 m from the ego, producing the most aggressive near-collision deceleration event.
param ADV_SPEED = 22
param ADV_DISTANCE = 5
param BRAKE_FORCE = 1.0

behavior AdvBehavior(target_ego, brake_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetBrakeAction(brake_intensity)

# 3. ROAD GEOMETRY
# The ego spawns ahead of the adversarial base point on a straight lane; the base point is sampled from the network lanes and the ego is placed a fixed distance forward to ensure the tailgater starts directly behind.
param GEO_Y_DISTANCE = 25
lane = Uniform(*network.lanes)
advBasePt = new OrientedPoint on lane.centerline
EgoSpawnPt = new OrientedPoint following roadDirection from advBasePt for globalParameters.GEO_Y_DISTANCE
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial tailgater spawns at the lane base point directly behind the ego at a static 25 m gap; the low adversarial speed closes this gap slowly, delaying the very-close trigger until the ego has less room to react.
advAgent = new Car at advBasePt offset by (0, 0, 0.5),
    with behavior AdvBehavior(ego, globalParameters.BRAKE_FORCE)
