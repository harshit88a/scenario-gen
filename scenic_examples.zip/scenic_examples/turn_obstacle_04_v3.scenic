# Scenario: The ego vehicle is turning left at a 4-way intersection; a Diamondback Century adversarial cyclist on the left front approaches at a fixed medium speed and stops at the connecting lane midpoint with a moderate threshold, creating a typical obstruction scenario with a distinct cyclist appearance.

# 1. MAP AND MODEL CONFIGURATION

param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial Diamondback Century cyclist waits until the ego reaches a static trigger of 12 m from the stop point, then rides at a fixed medium speed of 5.5 m/s and brakes fully within a static 3 m from the connecting lane midpoint, placing the bike squarely across the ego's turning arc.

param EGO_SPEED = Range(6, 10)
param ADV_SPEED = 5.5
param SAFETY_DIST = Range(8, 14)
param BRAKE_INTENSITY = 1.0
param ADV_STOP_THRESHOLD = 3
param EGO_TRIGGER_DIST = 12

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.EGO_SPEED, trajectory=trajectory)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

behavior AdversaryBehavior(trajectory, stop_point):
    while (distance from ego to stop_point) > globalParameters.EGO_TRIGGER_DIST:
        take SetThrottleAction(0), SetBrakeAction(0)
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.ADV_SPEED, trajectory=trajectory)
    interrupt when (distance from self to stop_point) < globalParameters.ADV_STOP_THRESHOLD:
        while True:
            take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        wait

# 3. ROAD GEOMETRY
# Only 4-way intersections are considered so the Diamondback Century has a full straight lane to traverse before entering the ego's connecting lane; the stop point is anchored at the midpoint of the connecting lane for maximum arc obstruction.

ADV_MODEL = "vehicle.diamondback.century"

def get_conflict_pairs(intersections):
    pairs = []
    for intersec in intersections:
        left_turns = filter(lambda m: m.type == ManeuverType.LEFT_TURN, intersec.maneuvers)
        for lt in left_turns:
            conflicts = filter(lambda c: c.type == ManeuverType.STRAIGHT, lt.conflictingManeuvers)
            for c in conflicts:
                pairs.append([lt, c])
    return pairs

four_way_intersections = filter(lambda i: i.is4Way, network.intersections)
valid_pairs = get_conflict_pairs(four_way_intersections)

require len(valid_pairs) > 0

selected_pair = Uniform(*valid_pairs)
ego_maneuver = selected_pair[0]
adv_maneuver = selected_pair[1]

ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]
adv_trajectory = [adv_maneuver.startLane, adv_maneuver.connectingLane, adv_maneuver.endLane]

connecting_pts = ego_maneuver.connectingLane.centerline.points
mid_idx = int(len(connecting_pts) / 2)
intersection_stop_pt = new OrientedPoint at connecting_pts[mid_idx]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The ego spawns at a static 20 m; the Diamondback Century spawns at a static 13 m from the intersection entry so that at medium speed it enters the intersection at the right moment relative to the 12 m ego trigger and settles at the midpoint stop within the 3 m threshold.

param EGO_DIST_TO_INTERSECTION = 20
param ADV_DIST_TO_INTERSECTION = 13

ego_anchor = new OrientedPoint at ego_maneuver.startLane.centerline.points[-1]
adv_anchor = new OrientedPoint at adv_maneuver.startLane.centerline.points[-1]

ego_spawn_pt = new OrientedPoint following roadDirection from ego_anchor for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_anchor for -globalParameters.ADV_DIST_TO_INTERSECTION

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Car at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with behavior AdversaryBehavior(adv_trajectory, intersection_stop_pt)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 80
