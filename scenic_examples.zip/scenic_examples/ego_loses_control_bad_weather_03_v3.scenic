# Scenario: Ego is forced to slalom through an extended four-box zigzag chain staggered alternately
# left and right at fixed positions with a tighter lateral offset, increasing the number of required
# steering corrections and extending the duration of the hazard zone.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Four static props alternating laterally at a fixed tighter offset to intensify slalom demands
param DEBRIS_START_DIST = 17
param DEBRIS_GAP = 8
param LATERAL_OFFSET = 0.7

behavior StaticObjectBehavior():
    while True:
        wait

# 3. ROAD GEOMETRY
# Ego cruises at a fixed moderately high speed toward the extended four-box zigzag chain
EGO_SPEED = 14

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 1.0),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=EGO_SPEED)

require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Four boxes alternate left and right at a fixed gap and fixed tight lateral offset
debris_spot_1 = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DEBRIS_START_DIST

debris1 = new Prop at debris_spot_1 offset by (globalParameters.LATERAL_OFFSET, 0, 0),
    with blueprint "static.prop.creasedbox01",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_2 = new OrientedPoint following roadDirection from debris_spot_1 for globalParameters.DEBRIS_GAP

debris2 = new Prop at debris_spot_2 offset by (-globalParameters.LATERAL_OFFSET, 0, 0),
    with blueprint "static.prop.creasedbox01",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_3 = new OrientedPoint following roadDirection from debris_spot_2 for globalParameters.DEBRIS_GAP

debris3 = new Prop at debris_spot_3 offset by (globalParameters.LATERAL_OFFSET, 0, 0),
    with blueprint "static.prop.creasedbox01",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_4 = new OrientedPoint following roadDirection from debris_spot_3 for globalParameters.DEBRIS_GAP

debris4 = new Prop at debris_spot_4 offset by (-globalParameters.LATERAL_OFFSET, 0, 0),
    with blueprint "static.prop.creasedbox01",
    with physics True,
    with behavior StaticObjectBehavior()

terminate when (distance from ego to EgoSpawnPt) > 80
