# Scenario: Ego vehicle drives straight at a standard speed; a brisk pedestrian steps from behind the furthest parked vehicle and stops in the lane, giving the ego a marginally longer but still insufficient warning distance.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The pedestrian walks briskly at 2.5 m/s for 2.0 seconds before stopping; the furthest parked distance is offset by the relatively fast crossing pace that places the pedestrian centrally in the lane.

param EGO_SPEED = 10
param PED_SPEED = 2.5
param PED_WALK_DURATION = 2.0

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)

behavior ParkedBehavior():
    take SetHandBrakeAction(True)

behavior CrossAndFreeze(ego, speed, duration):
    do CrossingBehavior(lambda: ego, speed, 300) for duration seconds
    terminate

# 3. ROAD GEOMETRY
# A straight road with a parking shoulder on the right side, far from any intersection.

from scenic.simulators.carla.behaviors import FollowLaneBehavior, CrossingBehavior
from scenic.simulators.carla.actions import SetHandBrakeAction

PARKED_MODEL = "vehicle.nissan.patrol"
PED_MODEL = "walker.pedestrian.0001"

initLane = Uniform(*network.lanes)
ego_spawn_pt = new OrientedPoint on initLane.centerline
parked_spawn_pt = new OrientedPoint right of ego_spawn_pt by 3.5

require (distance from ego_spawn_pt to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The parked vehicle is at the maximum 35 m ahead; the pedestrian hides 4.0 m behind it and jogs out, freezing mid-lane and blocking the standard-speed ego with a partially extended warning.

param PARKED_DIST = 35
param PED_DIST_FROM_CAR = 4.0

parked_spot = new OrientedPoint following roadDirection from parked_spawn_pt for globalParameters.PARKED_DIST

ped_ref_spot = new OrientedPoint following roadDirection from parked_spot for globalParameters.PED_DIST_FROM_CAR
ped_spawn_pt = new OrientedPoint right of ped_ref_spot by 0.5

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

parked_car = new Car at parked_spot offset by (0, 0, 0.5),
    with blueprint PARKED_MODEL,
    with behavior ParkedBehavior()

ped = new Pedestrian at ped_spawn_pt offset by (0, 0, 1),
    with blueprint PED_MODEL,
    with regionContainedIn None,
    with behavior CrossAndFreeze(ego, globalParameters.PED_SPEED, globalParameters.PED_WALK_DURATION)
