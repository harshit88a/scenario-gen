# Scenario: Ego drives straight and encounters an adversarial vehicle moving at a noticeably higher crawl speed before applying full brakes after a very short delay, creating a sudden speed differential from an initially less suspicious approach speed.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial vehicle travels at a fixed crawl speed of 8 m/s for only a static 2 seconds before applying maximum brakes; the brief crawl window at moderate speed gives the ego little time to adjust its following gap before the hard stop.
param ADV_SPEED = 8
param BRAKE_FORCE = 1.0

behavior AdvBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) for 2 seconds
    while True:
        take SetBrakeAction(globalParameters.BRAKE_FORCE)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection to keep the scenario focused on the short-window crawl-and-brake event.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial car spawns at a static far distance of 25 m ahead; the higher crawl speed at a far spawn means the ego must reduce the gap quickly, compressing the available braking margin when the 2-second delay expires.
param GEO_Y_DISTANCE = 25
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior AdvBehavior()
