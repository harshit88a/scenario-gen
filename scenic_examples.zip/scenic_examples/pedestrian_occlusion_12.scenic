# Scenario: A parked van fully occludes a fast pedestrian who dashes into the fast-moving ego's path at a close trigger distance, creating a simultaneous high-speed closing event that challenges both perception and braking.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.tesla.model3"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Pedestrian waits behind the van and jogs at 3.0 m/s once ego reaches 10 m; the short trigger combined with a fast ego at 14 m/s produces the shortest possible time-to-collision in this scenario set.

param PED_SPEED = 3.0
param TRIGGER_DIST = 10

behavior CrossingWalk(target_speed):
    while True:
        take SetWalkingDirectionAction(self.heading), SetWalkingSpeedAction(target_speed)

behavior PedestrianOcclusionBehavior(target_ego):
    while (distance from target_ego to self) > globalParameters.TRIGGER_DIST:
        wait
    do CrossingWalk(target_speed=globalParameters.PED_SPEED)

behavior ParkedBehavior():
    take SetBrakeAction(1.0)
    take SetHandBrakeAction(True)

# 3. ROAD GEOMETRY
# Straight lane in Town05 clear of intersections; ego cruises at 14 m/s, amplifying the danger of the close trigger and fast crossing pedestrian.

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=14)
require (distance to intersection) > 40

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Parked van placed 30 m ahead at a fixed -3.5 m side offset; the furthest van placement combined with the close trigger means the pedestrian remains hidden until the ego is almost upon them.

param OCCLUDER_DIST = 30
param SIDE_OFFSET = -3.5

van_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.OCCLUDER_DIST

occluder_van = new Car at van_spot offset by (globalParameters.SIDE_OFFSET, 0, 0.5),
    with blueprint "vehicle.ford.ambulance",
    with behavior ParkedBehavior()

ped_spawn = new OrientedPoint at (-0.5, 4.0) relative to occluder_van,
    facing 90 deg relative to occluder_van

bad_pedestrian = new Pedestrian at ped_spawn,
    with regionContainedIn None,
    with behavior PedestrianOcclusionBehavior(ego)

require (distance from bad_pedestrian to occluder_van) > 1
