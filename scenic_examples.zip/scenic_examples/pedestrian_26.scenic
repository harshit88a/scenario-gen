# Scenario: Ego vehicle drives straight at high speed; a very slow pedestrian creeps from behind a parked vehicle and halts in the lane, creating a stationary obstacle that the fast-moving ego struggles to avoid in time.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The pedestrian shuffles at 1.0 m/s for 3.0 seconds before stopping; the very slow pace means the pedestrian barely enters the lane but remains as an immovable obstacle directly in the high-speed ego's path.

param EGO_SPEED = 14
param PED_SPEED = 1.0
param PED_WALK_DURATION = 3.0

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)

behavior ParkedBehavior():
    take SetHandBrakeAction(True)

behavior CrossAndFreeze(ego, speed, duration):
    do CrossingBehavior(lambda: ego, speed, 300) for duration seconds
    terminate

# 3. ROAD GEOMETRY
# A straight road with a parking shoulder on the right side, well clear of any intersection to prevent external context from warning the high-speed ego.

from scenic.simulators.carla.behaviors import FollowLaneBehavior, CrossingBehavior
from scenic.simulators.carla.actions import SetHandBrakeAction

PARKED_MODEL = "vehicle.nissan.patrol"
PED_MODEL = "walker.pedestrian.0001"

initLane = Uniform(*network.lanes)
ego_spawn_pt = new OrientedPoint on initLane.centerline
parked_spawn_pt = new OrientedPoint right of ego_spawn_pt by 3.5

require (distance from ego_spawn_pt to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The parked vehicle is 28 m ahead; the slowly emerging pedestrian hides 4.0 m behind it and drifts into the lane edge, stopping just inside the path of the fast-moving ego.

param PARKED_DIST = 28
param PED_DIST_FROM_CAR = 4.0

parked_spot = new OrientedPoint following roadDirection from parked_spawn_pt for globalParameters.PARKED_DIST

ped_ref_spot = new OrientedPoint following roadDirection from parked_spot for globalParameters.PED_DIST_FROM_CAR
ped_spawn_pt = new OrientedPoint right of ped_ref_spot by 0.5

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

parked_car = new Car at parked_spot offset by (0, 0, 0.5),
    with blueprint PARKED_MODEL,
    with behavior ParkedBehavior()

ped = new Pedestrian at ped_spawn_pt offset by (0, 0, 1),
    with blueprint PED_MODEL,
    with regionContainedIn None,
    with behavior CrossAndFreeze(ego, globalParameters.PED_SPEED, globalParameters.PED_WALK_DURATION)
