# Scenario: Four creasedbox02 props scattered at sampled large intervals are approached by the
# ego vehicle at a sampled speed, sweeping the joint space of reaction distance and entry velocity
# to find the critical speed above which long-range debris detection fails.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Debris scattered at large sampled intervals; ego approach speed is independently sampled
param DEBRIS_START_DIST = Range(20, 30)
param DEBRIS_GAP = Range(12, 20)
param EGO_SPEED = Range(8, 16)

behavior StaticObjectBehavior():
    while True:
        wait

# 3. ROAD GEOMETRY
# Ego spawns on a long straight lane and drives at a sampled speed toward the spread-out debris
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 1.0),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED)

require (distance to intersection) > 80

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Four boxes chained at large sampled gaps with wide sampled lateral scatter spanning the full lane
debris_spot_1 = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DEBRIS_START_DIST

debris1 = new Prop at debris_spot_1 offset by (Range(-1.0, 1.0), 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_2 = new OrientedPoint following roadDirection from debris_spot_1 for globalParameters.DEBRIS_GAP

debris2 = new Prop at debris_spot_2 offset by (Range(-1.0, 1.0), 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_3 = new OrientedPoint following roadDirection from debris_spot_2 for globalParameters.DEBRIS_GAP

debris3 = new Prop at debris_spot_3 offset by (Range(-1.0, 1.0), 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

debris_spot_4 = new OrientedPoint following roadDirection from debris_spot_3 for globalParameters.DEBRIS_GAP

debris4 = new Prop at debris_spot_4 offset by (Range(-1.0, 1.0), 0, 0),
    with blueprint "static.prop.creasedbox02",
    with physics True,
    with behavior StaticObjectBehavior()

terminate when (distance from ego to EgoSpawnPt) > 100
