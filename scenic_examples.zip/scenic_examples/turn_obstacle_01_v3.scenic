# Scenario: The ego vehicle is turning left at an intersection at a fixed slow speed; a Kawasaki Ninja motorcyclist on the right front approaches at a fixed medium speed and brakes abruptly at the intersection edge, exploiting the ego's reduced reaction window due to its slow turn speed.

# 1. MAP AND MODEL CONFIGURATION

param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial Kawasaki Ninja rides at a static medium speed of 10 m/s along the conflicting straight lane and executes a full brake at a static trigger distance of 5 m from the lane endpoint, creating a deceptive halt that stalls the ego's slow left-turn progression.

param EGO_SPEED = 6
param ADV_SPEED = 10
param SAFETY_DIST = Range(8, 14)
param BRAKE_INTENSITY = 1.0
param ADV_BRAKE_TRIGGER_DIST = 5

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.EGO_SPEED, trajectory=trajectory)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

behavior AdversaryBehavior(trajectory, brake_point):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.ADV_SPEED, trajectory=trajectory)
    interrupt when (distance from self to brake_point) < globalParameters.ADV_BRAKE_TRIGGER_DIST:
        while True:
            take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        wait

# 3. ROAD GEOMETRY
# A 4-way intersection is selected to guarantee a full conflicting straight path for the Kawasaki Ninja; the left-turn and conflicting straight pair is sampled uniformly to vary the turning geometry across runs.

ADV_MODEL = "vehicle.kawasaki.ninja"

def get_conflict_pairs(intersections):
    pairs = []
    for intersec in intersections:
        left_turns = filter(lambda m: m.type == ManeuverType.LEFT_TURN, intersec.maneuvers)
        for lt in left_turns:
            conflicts = filter(lambda c: c.type == ManeuverType.STRAIGHT, lt.conflictingManeuvers)
            for c in conflicts:
                pairs.append([lt, c])
    return pairs

four_way_intersections = filter(lambda i: i.is4Way, network.intersections)
valid_pairs = get_conflict_pairs(four_way_intersections)

require len(valid_pairs) > 0

selected_pair = Uniform(*valid_pairs)
ego_maneuver = selected_pair[0]
adv_maneuver = selected_pair[1]

ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]
adv_trajectory = [adv_maneuver.startLane, adv_maneuver.connectingLane, adv_maneuver.endLane]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The ego spawns at a static 20 m from the intersection; the Kawasaki Ninja spawns at a static 15 m so that at medium speed it arrives at the brake point roughly concurrent with the ego entering the connecting lane.

param EGO_DIST_TO_INTERSECTION = 20
param ADV_DIST_TO_INTERSECTION = 15

ego_anchor = new OrientedPoint at ego_maneuver.startLane.centerline.points[-1]
adv_anchor = new OrientedPoint at adv_maneuver.startLane.centerline.points[-1]

ego_spawn_pt = new OrientedPoint following roadDirection from ego_anchor for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_anchor for -globalParameters.ADV_DIST_TO_INTERSECTION

adv_brake_point = new OrientedPoint at adv_maneuver.startLane.centerline.points[-1]

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Motorcycle at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with behavior AdversaryBehavior(adv_trajectory, adv_brake_point)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 80
