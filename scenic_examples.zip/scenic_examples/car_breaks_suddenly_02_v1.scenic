# Scenario: Ego drives straight and encounters an adversarial vehicle crawling at a very slow fixed speed for an extended duration before slamming to a full stop, luring the ego into an extremely close following position before the brake event.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial vehicle crawls at a fixed very slow speed of 2 m/s for a static 6 seconds before applying maximum brakes; the prolonged crawl phase draws the fast ego deep into the danger zone before the brake event fires.
param ADV_SPEED = 2
param BRAKE_FORCE = 1.0

behavior AdvBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) for 6 seconds
    while True:
        take SetBrakeAction(globalParameters.BRAKE_FORCE)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection to maintain the pure straight-road crawl-and-brake scenario.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial car spawns at a static close distance of 15 m ahead so the slow crawl phase and extended 6-second duration bring the ego to near-collision distance just as the brakes engage.
param GEO_Y_DISTANCE = 15
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior AdvBehavior()
