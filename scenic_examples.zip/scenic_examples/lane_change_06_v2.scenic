# Scenario: Fast ego vehicle (18 m/s) approaches a slow lead (8 m/s) and triggers a left lane change at 18 m proximity, requiring a quicker reaction due to the higher approach speed.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Slow lead at 8 m/s. Fast ego (18 m/s) triggers a left lane change at 18 m proximity for a high-speed evasion.

param EGO_SPEED = 18
param ADV_SPEED = 8
param DIST_THRESHOLD = 18

behavior SlowLeadBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED)

behavior EgoBehavior(target_section):
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance to advAgent) < globalParameters.DIST_THRESHOLD
    
    do LaneChangeBehavior(laneSectionToSwitch=target_section, target_speed=globalParameters.EGO_SPEED)
    
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED)

# 3. ROAD GEOMETRY
# A multi-lane straight road where the ego occupies a lane with a slow lead ahead, and an adjacent left lane is available for the evasive lane change.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

checkPt = new OrientedPoint left of spawnPt by 3.5
targetSection = network.laneSectionAt(checkPt)

require targetSection is not None
require getattr(targetSection, 'lane', None) != initLane

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(targetSection)

require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Slow lead spawns 30 m ahead of the fast ego, giving a longer initial gap before the evasion.

param START_DISTANCE = 30

adv_spot = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE

advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior SlowLeadBehavior()

require (distance from advAgent to intersection) > 20
