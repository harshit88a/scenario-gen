# Scenario: Slow ego vehicle (10 m/s) attempts a right lane change after 4 seconds; the fast adversary (14 m/s) in the right lane quickly overtakes and then remains a side-by-side threat, forcing the ego to brake at 10 m.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Fast adversary (14 m/s) overtakes slow ego (10 m/s) during the 4 s delay, then creates an unpredictable blocking position. Ego brakes at 10 m.

param EGO_SPEED = 10
param ADV_SPEED = 14
param SAFETY_DIST = 10

behavior AdversaryBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED)

behavior EgoBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) for 4 seconds
    rightSection = network.laneSectionAt(self)._laneToRight
    try:
        do LaneChangeBehavior(laneSectionToSwitch=rightSection, target_speed=globalParameters.EGO_SPEED)
    interrupt when (distance to adversary) < globalParameters.SAFETY_DIST:
        take SetBrakeAction(0.8)
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED)

# 3. ROAD GEOMETRY
# A multi-lane straight road where the ego occupies a lane and the adversarial vehicle occupies the right adjacent lane in parallel.

valid_lane_pairs = []
for lane in network.lanes:
    for sec in lane.sections:
        right_sec = sec._laneToRight
        if right_sec is not None:
            valid_lane_pairs.append((lane, right_sec.lane))
            break

selected_pair = Uniform(*valid_lane_pairs)
initLane = selected_pair[0]
rightLane = selected_pair[1]

spawnPt = new OrientedPoint on initLane.centerline
advPt = new OrientedPoint on rightLane.centerline

require (distance from spawnPt to intersection) > 60
require (distance from advPt to intersection) > 40

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Ego spawns alongside the adversary; the adversary's higher speed creates an overtaking then blocking dynamic during the lane change.

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior()

adversary = new Car at advPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior AdversaryBehavior()

require (distance from ego to adversary) < 8
