# Scenario: The ego vehicle is turning right at a 4-way intersection at a fixed slow speed; the adversarial pedestrian crosses at a fixed brisk pace and freezes mid-arc, maximising conflict duration due to the ego's slow progression through the turn.

# 1. MAP AND MODEL CONFIGURATION

param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial pedestrian activates at a static trigger distance of 10 m from the stop point and moves at a fixed brisk speed of 1.8 m/s; the ego's fixed slow speed of 6 m/s ensures the pedestrian reaches the freeze point well before the ego clears the right-turn arc.

param EGO_SPEED = 6
param ADV_SPEED = 1.8
param SAFETY_DIST = Range(8, 14)
param BRAKE_INTENSITY = 1.0
param ADV_STOP_THRESHOLD = 2.0
param ADV_LATERAL_OFFSET = Range(4, 6)
param EGO_TRIGGER_DIST = 10

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(target_speed=globalParameters.EGO_SPEED, trajectory=trajectory)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

behavior AdversaryBehavior(stop_point):
    while (distance from ego to stop_point) > globalParameters.EGO_TRIGGER_DIST:
        take SetWalkingSpeedAction(0)
    try:
        while True:
            take SetWalkingDirectionAction(self.heading), SetWalkingSpeedAction(globalParameters.ADV_SPEED)
    interrupt when (distance from self to stop_point) < globalParameters.ADV_STOP_THRESHOLD:
        while True:
            take SetWalkingSpeedAction(0)

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        wait

# 3. ROAD GEOMETRY
# Only 4-way intersections are considered to ensure the right-turn geometry provides a full perpendicular crossing path for the brisk pedestrian; maneuvers are sampled uniformly across valid 4-way right-turn sites in Town05.

ADV_MODEL = "walker.pedestrian.0001"

def get_right_turn_maneuvers(intersections):
    maneuvers = []
    for intersec in intersections:
        right_turns = filter(lambda m: m.type == ManeuverType.RIGHT_TURN, intersec.maneuvers)
        for rt in right_turns:
            maneuvers.append(rt)
    return maneuvers

four_way_intersections = filter(lambda i: i.is4Way, network.intersections)
valid_maneuvers = get_right_turn_maneuvers(four_way_intersections)

require len(valid_maneuvers) > 0

ego_maneuver = Uniform(*valid_maneuvers)
ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]

intersection_stop_pt = new OrientedPoint at ego_maneuver.connectingLane.centerline.points[0]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The ego spawns at a static 15 m; the pedestrian spawns with a sampled lateral offset of 4–6 m from the stop point facing toward it, so the brisk walking speed covers the short crossing distance before the slow ego clears the arc.

param EGO_DIST_TO_INTERSECTION = 15

ego_anchor = new OrientedPoint at ego_maneuver.startLane.centerline.points[-1]
ego_spawn_pt = new OrientedPoint following roadDirection from ego_anchor for -globalParameters.EGO_DIST_TO_INTERSECTION

adv_spawn_pt = new OrientedPoint at intersection_stop_pt offset by (globalParameters.ADV_LATERAL_OFFSET, 0, 0)

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Pedestrian at adv_spawn_pt,
    with blueprint ADV_MODEL,
    with regionContainedIn None,
    facing toward intersection_stop_pt,
    with behavior AdversaryBehavior(intersection_stop_pt)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 80
