# Scenario: Ego vehicle drives straight and faces an extreme braking challenge when a running pedestrian emerges from the far-right shoulder at maximum trigger distance, crossing fast and occupying the ego's path with minimal warning time.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial pedestrian jogs at 2.5 m/s and is triggered at only 10 m from the ego, leaving the ego almost no distance in which to bring the vehicle to a safe stop.

from scenic.simulators.carla.behaviors import CrossingBehavior

param EGO_SPEED = 10
param PED_SPEED = 2.5
param TRIGGER_DIST = 10

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)

# 3. ROAD GEOMETRY
# A straight road far from intersections, maximising the element of surprise when the pedestrian steps out.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The pedestrian is placed 30 m ahead at the maximum 4.5 m lateral offset, making them visually peripheral until the very last moment before trigger.

param START_DISTANCE = 30
param LATERAL_OFFSET = 4.5

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

adv_spot_road = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE
ped_spawn = new OrientedPoint right of adv_spot_road by globalParameters.LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to adv_spot_road.heading,
    with regionContainedIn None,
    with behavior CrossingBehavior(ego, globalParameters.PED_SPEED, globalParameters.TRIGGER_DIST)

require ped not in network.drivableRegion
