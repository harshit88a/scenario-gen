# Scenario: Ego vehicle is driving on a straight road; a pedestrian behind a parked car is triggered very late and stops almost in contact with the ego. Reduced trigger and stop distances produce the minimum-margin parked-car ambush scenario.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian does not emerge until the ego is only 12 m away, then dashes at 3.5 m/s and freezes just 1.5 m in front of the ego; the late trigger and near-contact stop distance leave the ego with the absolute minimum braking margin after the pedestrian enters the lane.

param EGO_SPEED = 10
param PED_EMERGE_SPEED = 3.5
param TRIGGER_DIST = 12
param STOP_DIST = 1.5

behavior PedestrianParkedCarAmbushBehavior(emerge_speed, trigger_dist, stop_dist):
    while (distance from self to ego) > trigger_dist:
        take SetWalkingSpeedAction(0)
    while True:
        if (distance from self to ego) <= stop_dist:
            take SetWalkingSpeedAction(0)
            break
        else:
            take SetWalkingDirectionAction(self.heading)
            take SetWalkingSpeedAction(emerge_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 70 m from any intersection; the parked car reference is placed 22 m ahead; the 12 m trigger means the ego has covered most of the longitudinal gap before the pedestrian moves.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 70
require (distance from spawnPt to initLane.centerline[-1]) > 50


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The parked car sits 22 m ahead and 3.5 m right; the pedestrian hides 4.5 m right and 2.0 m rearward; the late 12 m trigger and 1.5 m stop distance represent the most dangerous parked-car ambush variant with the smallest possible avoidance margin.

param START_DISTANCE = 22
param CAR_LATERAL_OFFSET = 3.5
param PED_HIDE_OFFSET = 2.0
param PED_LATERAL_OFFSET = 4.5

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

parked_car_ref = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE

parked_car = new Car right of parked_car_ref by globalParameters.CAR_LATERAL_OFFSET,
    with blueprint Uniform(
        "vehicle.tesla.model3",
        "vehicle.toyota.prius",
        "vehicle.audi.a2"
    ),
    with behavior None

ped_spawn = new OrientedPoint right of parked_car_ref by globalParameters.PED_LATERAL_OFFSET

ped = new Pedestrian at ped_spawn offset by (-globalParameters.PED_HIDE_OFFSET, 0, 1),
    facing 90 deg relative to parked_car_ref.heading,
    with regionContainedIn None,
    with behavior PedestrianParkedCarAmbushBehavior(
        globalParameters.PED_EMERGE_SPEED,
        globalParameters.TRIGGER_DIST,
        globalParameters.STOP_DIST
    )

require ped not in network.drivableRegion
require parked_car not in network.drivableRegion
