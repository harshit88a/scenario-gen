# Scenario: The ego is performing a right turn at an intersection when the crossing car surges to an elevated speed; mid-range spawn distances with an increased surge speed and an earlier ego safety detection distance to widen the avoidance window.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The adversarial car approaches at 10 m/s then surges to 35 m/s once within 28 m of the ego; the ego is set to detect the threat at a wider 20 m safety distance, giving it additional reaction time against the elevated surge speed.

param EGO_SPEED = 7
param ADV_SPEED = 10
param ADV_SURGE_SPEED = 35
param SAFETY_DIST = 20
param BRAKE_INTENSITY = 1.0
param ADV_SURGE_TRIGGER_DIST = 28

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        if withinDistanceToTrafficLight(adversary, 100):
            setClosestTrafficLightStatus(adversary, "green")
        wait

behavior AdversaryBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.ADV_SPEED)
    interrupt when (distance from self to ego) < globalParameters.ADV_SURGE_TRIGGER_DIST:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.ADV_SURGE_SPEED)

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.EGO_SPEED)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)


# 3. ROAD GEOMETRY
### A four-way intersection where the ego turns right and the adversary crosses straight from a perpendicular lane; mid-range 12 m ego and 21 m adversary spawns balanced against an elevated 35 m/s surge speed.

ADV_MODEL = "vehicle.tesla.model3"

fourWayIntersections = filter(lambda i: i.is4Way, network.intersections)
intersec = Uniform(*fourWayIntersections)

ego_maneuvers = filter(lambda i: i.type == ManeuverType.RIGHT_TURN, intersec.maneuvers)
ego_maneuver = Uniform(*ego_maneuvers)
ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]

adv_maneuvers = filter(lambda i: i.type == ManeuverType.STRAIGHT, ego_maneuver.conflictingManeuvers)
adv_maneuver = Uniform(*adv_maneuvers)
adv_trajectory = [adv_maneuver.startLane, adv_maneuver.connectingLane, adv_maneuver.endLane]


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### Ego spawns 12 m from the intersection; adversary spawns 21 m back on its straight conflicting lane; the wider 20 m ego safety distance tests whether early detection is sufficient to handle the elevated 35 m/s surge.

param EGO_DIST_TO_INTERSECTION = 12
param ADV_DIST_TO_INTERSECTION = 21

ego_init_pt = new OrientedPoint in ego_maneuver.startLane.centerline
adv_init_pt = new OrientedPoint in adv_maneuver.startLane.centerline

ego_spawn_pt = new OrientedPoint following roadDirection from ego_init_pt for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_init_pt for -globalParameters.ADV_DIST_TO_INTERSECTION

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Car at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with behavior AdversaryBehavior(adv_trajectory)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 100
