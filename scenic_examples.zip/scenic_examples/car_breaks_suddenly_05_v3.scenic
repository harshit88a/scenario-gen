# Scenario: Ego approaches at a fixed moderate speed and encounters a fully stationary Volkswagen T2 bus stalled at the baseline mid-range distance ahead, testing the ego's response to a wide low vehicle at a typical following distance.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial Volkswagen T2 bus holds maximum brake force of 1.0 for the entire scenario duration, remaining fully stationary; the wide bus silhouette blocks the full lane width, ensuring the ego cannot pass and must stop.
param BRAKE_FORCE = 1.0

behavior AdvBehavior():
    while True:
        take SetBrakeAction(globalParameters.BRAKE_FORCE)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection and runs at a fixed moderate approach speed of 12 m/s, representing a realistic urban approach speed toward a stalled bus.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=12)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial Volkswagen T2 bus spawns at the baseline static distance of 22 m ahead; the moderate ego speed and standard gap replicate the original scenario's core distance with a distinct large-vehicle adversary model.
param GEO_Y_DISTANCE = 22
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with blueprint "vehicle.volkswagen.t2",
    with behavior AdvBehavior()
