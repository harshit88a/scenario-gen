# Scenario: Ego drives straight; an Audi TT leading car travels at a fixed medium speed, then brakes hard at a mid-range trigger distance, combining a different adversary silhouette with a classic sudden-braking hazard.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial Audi TT travels at a fixed medium speed of 7 m/s and applies a hard brake force of 0.8 once the ego closes to a static trigger distance of 15 m, creating a firm but not maximum deceleration event mid-range ahead.
param ADV_SPEED = 7
param ADV_DISTANCE = 15
param BRAKE_FORCE = 0.8

behavior AdvBehavior(target_ego, brake_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetBrakeAction(brake_intensity)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection to keep the scenario focused on the straight-road braking reaction.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial Audi TT spawns at a static 22 m ahead of the ego, placing the medium-speed approach and mid-range brake trigger in a realistic highway-speed following distance scenario.
param GEO_Y_DISTANCE = 22
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with blueprint "vehicle.audi.tt",
    with behavior AdvBehavior(ego, globalParameters.BRAKE_FORCE)
