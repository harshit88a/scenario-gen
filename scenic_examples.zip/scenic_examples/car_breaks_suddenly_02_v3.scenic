# Scenario: Ego drives straight and encounters an adversarial Nissan Patrol SUV crawling at medium speed before applying a partial brake after a moderate delay, simulating a heavy vehicle slow-down that the ego must respond to with firm but not maximum braking.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial Nissan Patrol SUV crawls at a fixed medium speed of 4 m/s for a static 3 seconds before applying a partial brake force of 0.7; the moderate deceleration from a heavy SUV silhouette creates a realistic heavy-vehicle braking hazard.
param ADV_SPEED = 4
param BRAKE_FORCE = 0.7

behavior AdvBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) for 3 seconds
    while True:
        take SetBrakeAction(globalParameters.BRAKE_FORCE)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection so the heavy-SUV partial-braking scenario is evaluated in an open straight-road context.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial Nissan Patrol spawns at a static 20 m ahead of the ego; the medium speed and 3-second crawl window give the ego a realistic opportunity to observe the SUV decelerating before the partial brake engages.
param GEO_Y_DISTANCE = 20
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with blueprint "vehicle.nissan.patrol",
    with behavior AdvBehavior()
