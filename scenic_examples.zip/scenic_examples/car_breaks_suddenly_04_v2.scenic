# Scenario: The adversarial leading car crawls at the maximum fixed slow speed before surging to the minimum fixed fast speed, producing the smallest speed differential from the most plausible crawl behavior at a generous trigger and spawn distance.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial car crawls at a fixed faster slow speed of 7 m/s, which is less obviously slow and more deceptive, then surges to the minimum fast speed of 28 m/s when the ego reaches the static far trigger distance of 18 m; the moderate differential still creates a dangerous gap opening event.
param ADV_SLOW_SPEED = 7
param ADV_FAST_SPEED = 28
param ADV_DISTANCE = 18

behavior AdvBehavior(target_ego):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SLOW_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    do FollowLaneBehavior(target_speed=globalParameters.ADV_FAST_SPEED)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection so the plausible crawl-and-moderate-surge event is exercised across diverse Town05 straight segments.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial car spawns at a static far distance of 22 m ahead of the ego; the faster slow crawl speed and far spawn give the ego a longer observability window before the far trigger fires and the moderate surge begins.
param GEO_Y_DISTANCE = 22
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior AdvBehavior(ego)
