# Scenario: Ego vehicle drives straight through an intersection at high speed and must decelerate sharply when a slow pedestrian enters the crosswalk at an early trigger distance; despite the early warning, the high ego speed requires maximum braking effort.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# The adversarial pedestrian walks at 1.5 m/s and triggers at 20 m from the ego; the high ego speed more than compensates for the early trigger, demanding maximum deceleration to avoid a collision.

from scenic.simulators.carla.behaviors import CrossingBehavior
from scenic.domains.driving.roads import ManeuverType

param EGO_SPEED = 14
param PED_SPEED = 1.5
param TRIGGER_DIST = 20

behavior EgoBehavior(trajectory):
    do FollowTrajectoryBehavior(target_speed=globalParameters.EGO_SPEED, trajectory=trajectory)

# 3. ROAD GEOMETRY
# A 3-way or 4-way intersection in Town05 with a straight-through maneuver trajectory for the high-speed ego.

intersections = filter(lambda i: i.is4Way or i.is3Way, network.intersections)
intersection = Uniform(*intersections)

straight_maneuvers = filter(lambda m: m.type is ManeuverType.STRAIGHT, intersection.maneuvers)
egoManeuver = Uniform(*straight_maneuvers)

egoInitLane = egoManeuver.startLane
egoTrajectory = [egoInitLane, egoManeuver.connectingLane, egoManeuver.endLane]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# The pedestrian is at 3.0 m lateral offset from the exit lane start, representing a narrow near-side crosswalk position that the slow pedestrian blocks for the entire duration of the ego's emergency stop.

param PED_OFFSET = 3.0

egoSpawnPt = new OrientedPoint in egoInitLane.centerline

ego = new Car at egoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(egoTrajectory)

require 20 <= (distance from ego to egoInitLane.centerline[-1]) <= 25

exit_point = new OrientedPoint at egoManeuver.endLane.centerline[0]
ped_spawn = new OrientedPoint right of exit_point by globalParameters.PED_OFFSET

ped = new Pedestrian at ped_spawn offset by (0, 0, 1),
    facing 90 deg relative to exit_point.heading,
    with regionContainedIn None,
    with behavior CrossingBehavior(ego, globalParameters.PED_SPEED, globalParameters.TRIGGER_DIST)

require ped not in network.drivableRegion

terminate when (distance to egoSpawnPt) > 70
