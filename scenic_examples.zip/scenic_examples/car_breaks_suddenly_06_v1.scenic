# Scenario: An adversarial vehicle in the adjacent left lane travels at a fixed slow speed and cuts sharply into the ego's lane at a close trigger distance, producing a tight cut-in event from the left side with minimal gap before the steer action engages.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial vehicle follows its adjacent left lane at a fixed slow speed of 15 m/s and applies a static steer intensity of 0.5 into the ego's lane once the ego closes to a static trigger distance of 10 m, producing an aggressive cut-in with limited escape margin for the ego.
param ADV_SPEED = 15
param ADV_DISTANCE = 10
param STEER_INTENSITY = 0.5

behavior AdvBehavior(target_ego, steer_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetSteerAction(steer_intensity)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection to keep the cut-in scenario isolated to straight-road lane-change dynamics.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial car spawns at a static close distance of 15 m ahead and one lane-width to the left of the ego at the standard -3.5 m lateral offset; the slow approach speed and close spawn bring the cut-in trigger almost immediately after scenario start.
param GEO_Y_DISTANCE = 15
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (-3.5, 0, 0.5),
    with behavior AdvBehavior(ego, globalParameters.STEER_INTENSITY)
