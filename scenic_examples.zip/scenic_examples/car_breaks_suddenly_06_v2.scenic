# Scenario: An Audi A2 adversarial vehicle in the adjacent left lane travels at a fixed high speed and cuts into the ego's lane at a far trigger distance, producing a high-speed cut-in with a longer lead-up phase that gives the ego false confidence before the lane violation.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversarial Audi A2 follows its adjacent left lane at a fixed high speed of 25 m/s and applies a static steer intensity of 0.5 into the ego's lane at the static far trigger distance of 20 m; the high speed makes the cut-in trajectory cover the lane width very rapidly.
param ADV_SPEED = 25
param ADV_DISTANCE = 20
param STEER_INTENSITY = 0.5

behavior AdvBehavior(target_ego, steer_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED) until \
        (distance from target_ego to self) < globalParameters.ADV_DISTANCE
    while True:
        take SetSteerAction(steer_intensity)

# 3. ROAD GEOMETRY
# Ego spawns on a uniformly sampled straight lane segment well clear of any intersection to focus the evaluation on the straight-road high-speed cut-in dynamics.
lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline
ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=15)
require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Adversarial Audi A2 spawns at a static far distance of 30 m ahead and one lane-width to the left of the ego; the high approach speed quickly closes the 30 m gap, bringing the far trigger into play just as the ego is fully committed to following behind.
param GEO_Y_DISTANCE = 30
adv_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.GEO_Y_DISTANCE
advAgent = new Car at adv_spot offset by (-3.5, 0, 0.5),
    with blueprint "vehicle.audi.a2",
    with behavior AdvBehavior(ego, globalParameters.STEER_INTENSITY)
