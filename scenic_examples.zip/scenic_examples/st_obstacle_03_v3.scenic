# Scenario: Ego vehicle is driving on a straight road; the adversarial pedestrian emerges quickly from a driveway on the left, holds longer in the road, then walks diagonally. Mid-range spawns with a faster emergence speed and extended mid-road stop duration.


# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
### The pedestrian idles at 22 m until the ego closes to 22 m then emerges at a faster 5.0 m/s, stops for an extended 50 ticks in the road centre, and then walks diagonally at 1.5 m/s; the higher emergence speed puts the pedestrian in the lane sooner while the longer stop increases the total obstruction duration.

param EGO_SPEED = 10
param PED_INITIAL_SPEED = 5.0
param PED_DIAGONAL_SPEED = 1.5
param TRIGGER_DIST = 22
param STOP_DURATION = 50
param DIAGONAL_ANGLE = 45

behavior PedestrianDrivewayDiagonalBehavior(initial_speed, diagonal_speed, trigger_dist, stop_duration, diagonal_angle):
    while (distance from self to ego) > trigger_dist:
        take SetWalkingSpeedAction(0)
    while (distance from self to ego) > (trigger_dist - 6):
        take SetWalkingDirectionAction(self.heading)
        take SetWalkingSpeedAction(initial_speed)
    for _ in range(stop_duration):
        take SetWalkingSpeedAction(0)
    diag_heading = self.heading + diagonal_angle deg
    while True:
        take SetWalkingDirectionAction(diag_heading)
        take SetWalkingSpeedAction(diagonal_speed)

behavior EgoBehavior(target_speed):
    do FollowLaneBehavior(target_speed=target_speed)


# 3. ROAD GEOMETRY
### A straight road section at least 70 m from any intersection; the driveway reference is placed 22 m ahead at a mid-range distance, balancing the emergence run-up time against the extended road-blocking duration.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

require (distance from spawnPt to intersection) > 70
require (distance from spawnPt to initLane.centerline[-1]) > 50


# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
### The pedestrian spawns 22 m ahead and 4.8 m to the left with a 1.5 m setback; the fast 5.0 m/s emergence combined with a 50-tick stop maximises the time the pedestrian is stationary in the road, increasing collision probability if the ego cannot stop.

param START_DISTANCE = 22
param LATERAL_OFFSET = 4.8
param DRIVEWAY_SETBACK = 1.5

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(globalParameters.EGO_SPEED)

driveway_ref = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE

ped_spawn = new OrientedPoint left of driveway_ref by globalParameters.LATERAL_OFFSET,
    facing driveway_ref.heading

ped = new Pedestrian at ped_spawn offset by (-globalParameters.DRIVEWAY_SETBACK, 0, 1),
    facing 270 deg relative to driveway_ref.heading,
    with regionContainedIn None,
    with behavior PedestrianDrivewayDiagonalBehavior(
        globalParameters.PED_INITIAL_SPEED,
        globalParameters.PED_DIAGONAL_SPEED,
        globalParameters.TRIGGER_DIST,
        globalParameters.STOP_DURATION,
        globalParameters.DIAGONAL_ANGLE
    )

require ped not in network.drivableRegion
