# Scenario: Two vehicles chained ahead of ego trigger a cascading emergency braking event at fully static distances; all Range-sampled parameters are converted to fixed values to create a fully deterministic multi-vehicle chain-reaction benchmark.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Both front and mid cars drive at a fixed speed and brake at a fixed trigger distance from their target
param LEAD_SPEED = 12
param OBSTACLE_BRAKE_DIST = 12
param BRAKE_FORCE = 1.0

behavior LeadCarBehavior(target_obstacle, brake_intensity):
    do FollowLaneBehavior(target_speed=globalParameters.LEAD_SPEED) until \
        (distance from target_obstacle to self) < globalParameters.OBSTACLE_BRAKE_DIST
    while True:
        take SetBrakeAction(brake_intensity)

# 3. ROAD GEOMETRY
# Ego drives at standard speed toward the two-car chain on a straight lane at fixed geometry
EGO_SPEED = 12

lane = Uniform(*network.lanes)
EgoSpawnPt = new OrientedPoint on lane.centerline

ego = new Car at EgoSpawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior FollowLaneBehavior(target_speed=EGO_SPEED)

require (distance to intersection) > 80

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Mid, front, and obstacle positions are all fixed to lock in the cascade geometry
param DIST_EGO_TO_MID = 12
param DIST_MID_TO_FRONT = 15
param DIST_FRONT_TO_OBSTACLE = 33

mid_spot = new OrientedPoint following roadDirection from EgoSpawnPt for globalParameters.DIST_EGO_TO_MID

front_spot = new OrientedPoint following roadDirection from mid_spot for globalParameters.DIST_MID_TO_FRONT

obs_spot = new OrientedPoint following roadDirection from front_spot for globalParameters.DIST_FRONT_TO_OBSTACLE

obstacle = new Prop at obs_spot offset by (0, 0, 0.5),
    with blueprint "static.prop.trashcan01"

frontCar = new Car at front_spot offset by (0, 0, 0.5),
    with behavior LeadCarBehavior(obstacle, globalParameters.BRAKE_FORCE)

midCar = new Car at mid_spot offset by (0, 0, 0.5),
    with behavior LeadCarBehavior(frontCar, globalParameters.BRAKE_FORCE)

terminate when ego.speed < 0.1 and (distance to midCar) < 5
