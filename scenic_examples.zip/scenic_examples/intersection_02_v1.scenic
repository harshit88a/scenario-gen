# Scenario: Ego vehicle approaches a 4-way intersection at 7 m/s; the adversarial car from the right crawls at 5 m/s, surges to 18 m/s once the ego is within 25 m, crosses and clears the intersection, then stops hard on the exit lane.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"


# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Adversary crawls at 5 m/s, surges to 18 m/s on 25 m ego proximity trigger, clears intersection then full brake on endLane. Ego brakes on 12 m safety distance.

param EGO_SPEED = 7
param ADV_SPEED = 5
param ADV_FAST_SPEED = 18
param SAFETY_DIST = 12
param BRAKE_INTENSITY = 1.0
param ADV_BRAKE_INTENSITY = 1.0
param ADV_ACCEL_TRIGGER_DIST = 25

monitor GreenWave():
    freezeTrafficLights()
    while True:
        if withinDistanceToTrafficLight(ego, 100):
            setClosestTrafficLightStatus(ego, "green")
        if withinDistanceToTrafficLight(adversary, 100):
            setClosestTrafficLightStatus(adversary, "green")
        wait

behavior AdversaryBehavior(trajectory, endLane):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.ADV_SPEED)
    interrupt when (distance from self to ego) < globalParameters.ADV_ACCEL_TRIGGER_DIST:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.ADV_FAST_SPEED) until (self in endLane)
        while True:
            take SetBrakeAction(globalParameters.ADV_BRAKE_INTENSITY)

behavior EgoBehavior(trajectory):
    try:
        do FollowTrajectoryBehavior(trajectory=trajectory, target_speed=globalParameters.EGO_SPEED)
    interrupt when withinDistanceToAnyObjs(self, globalParameters.SAFETY_DIST):
        take SetBrakeAction(globalParameters.BRAKE_INTENSITY)

# 3. ROAD GEOMETRY
# A four-way intersection where the ego proceeds straight and the adversary approaches from the right on a conflicting straight path, creating a right-of-way contest.

ADV_MODEL = "vehicle.tesla.model3"

fourWayIntersections = filter(lambda i: i.is4Way, network.intersections)
intersec = Uniform(*fourWayIntersections)

ego_maneuvers = filter(lambda i: i.type == ManeuverType.STRAIGHT, intersec.maneuvers)
ego_maneuver = Uniform(*ego_maneuvers)
ego_trajectory = [ego_maneuver.startLane, ego_maneuver.connectingLane, ego_maneuver.endLane]

adv_maneuvers = filter(lambda i: i.type == ManeuverType.STRAIGHT, ego_maneuver.conflictingManeuvers)
adv_maneuver = Uniform(*adv_maneuvers)
adv_trajectory = [adv_maneuver.startLane, adv_maneuver.connectingLane, adv_maneuver.endLane]

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Ego spawns 14 m from intersection; adversary spawns 18 m back on the right conflicting straight lane.

param EGO_DIST_TO_INTERSECTION = 14
param ADV_DIST_TO_INTERSECTION = 18

ego_init_pt = new OrientedPoint in ego_maneuver.startLane.centerline
adv_init_pt = new OrientedPoint in adv_maneuver.startLane.centerline

ego_spawn_pt = new OrientedPoint following roadDirection from ego_init_pt for -globalParameters.EGO_DIST_TO_INTERSECTION
adv_spawn_pt = new OrientedPoint following roadDirection from adv_init_pt for -globalParameters.ADV_DIST_TO_INTERSECTION

ego = new Car at ego_spawn_pt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(ego_trajectory)

adversary = new Car at adv_spawn_pt offset by (0, 0, 0.5),
    with blueprint ADV_MODEL,
    with behavior AdversaryBehavior(adv_trajectory, adv_maneuver.endLane)

require monitor GreenWave()
terminate when (distance to ego_spawn_pt) > 100
