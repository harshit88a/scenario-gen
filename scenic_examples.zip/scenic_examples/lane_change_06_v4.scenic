# Scenario: Slow ego vehicle (12 m/s) approaches a faster lead (8 m/s) in the same lane and triggers a left lane change at 17 m proximity, representing a moderate differential evasion.

# 1. MAP AND MODEL CONFIGURATION
param map = localPath('./../CARLA_0.9.15/CarlaUE4/Content/Carla/Maps/OpenDrive/Town05.xodr')
param carla_map = 'Town05'
param use2DMap = True
model scenic.simulators.carla.model
EGO_MODEL = "vehicle.lincoln.mkz_2017"

# 2. ADV BEHAVIOR OF THE SURROUNDING OBJECT
# Lead at 8 m/s, slow ego at 12 m/s. Moderate speed differential; lane change triggered at 17 m proximity.

param EGO_SPEED = 12
param ADV_SPEED = 8
param DIST_THRESHOLD = 17

behavior SlowLeadBehavior():
    do FollowLaneBehavior(target_speed=globalParameters.ADV_SPEED)

behavior EgoBehavior(target_section):
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED) until \
        (distance to advAgent) < globalParameters.DIST_THRESHOLD
    
    do LaneChangeBehavior(laneSectionToSwitch=target_section, target_speed=globalParameters.EGO_SPEED)
    
    do FollowLaneBehavior(target_speed=globalParameters.EGO_SPEED)

# 3. ROAD GEOMETRY
# A multi-lane straight road where the ego occupies a lane with a slow lead ahead, and an adjacent left lane is available for the evasive lane change.

initLane = Uniform(*network.lanes)
spawnPt = new OrientedPoint on initLane.centerline

checkPt = new OrientedPoint left of spawnPt by 3.5
targetSection = network.laneSectionAt(checkPt)

require targetSection is not None
require getattr(targetSection, 'lane', None) != initLane

ego = new Car at spawnPt offset by (0, 0, 0.5),
    with blueprint EGO_MODEL,
    with behavior EgoBehavior(targetSection)

require (distance to intersection) > 50

# 4. RELATIVE SPAWN POSITION OF THE ADVERSARIAL AGENT
# Lead spawns 28 m ahead of the slow ego in the same lane.

param START_DISTANCE = 28

adv_spot = new OrientedPoint following roadDirection from spawnPt for globalParameters.START_DISTANCE

advAgent = new Car at adv_spot offset by (0, 0, 0.5),
    with behavior SlowLeadBehavior()

require (distance from advAgent to intersection) > 20
